#!/usr/bin/env python3
"""Create a self-checking return archive with results and probabilities."""

from __future__ import print_function

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import zipfile


PACKAGE_ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work-dir", type=Path, required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    work = args.work_dir.resolve()
    report = json.loads((work / "verification_report.json").read_text(encoding="utf-8"))
    if report.get("status") != "passed":
        raise SystemExit("Refusing to package results without a passed verification report")
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    archive = work / ("EVSpSegNet_full_ab_return_" + timestamp + ".zip")
    metadata = work / "return_metadata"
    metadata.mkdir(parents=True, exist_ok=True)
    readme = metadata / "RETURN_README.md"
    readme.write_text(
        "# EV-SpSegNet A+B return package\n\n"
        "This archive passed A event/track accuracy and B model-complexity verification on all 48 frozen sequences. "
        "Run `python tools/import_ev_spsegnet_results.py <this-archive.zip>` from the local project to import it. "
        "Keep `predictions/` and provenance files as the reproducibility record.\n",
        encoding="utf-8",
    )
    source_entries = []
    for root_name in ("results", "predictions"):
        root = work / root_name
        if not root.is_dir():
            raise SystemExit("Missing return directory: {}".format(root))
        for path in sorted(item for item in root.rglob("*") if item.is_file()):
            source_entries.append((path, path.relative_to(work).as_posix()))
    for filename in (
        "provenance.json", "verification_report.json", "server_inspection.json",
        "source_archive.json",
    ):
        path = work / filename
        if path.is_file():
            source_entries.append((path, filename))
    for path, arcname in (
        (PACKAGE_ROOT / "frozen" / "index.json", "frozen/index.json"),
        (PACKAGE_ROOT / "frozen" / "target_track_protocol.json", "frozen/target_track_protocol.json"),
        (PACKAGE_ROOT / "VERSION.json", "frozen/server_package_VERSION.json"),
        (PACKAGE_ROOT / "tools" / "import_ev_spsegnet_results.py", "tools/import_ev_spsegnet_results.py"),
        (readme, "RETURN_README.md"),
    ):
        source_entries.append((path, arcname))
    manifest = {
        "status": "verified",
        "created_local_time": dt.datetime.now().astimezone().isoformat(),
        "files": [
            {"path": arcname, "bytes": path.stat().st_size, "sha256": sha256(path)}
            for path, arcname in source_entries
        ],
    }
    manifest_path = metadata / "RETURN_MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    source_entries.append((manifest_path, "RETURN_MANIFEST.json"))
    with zipfile.ZipFile(str(archive), "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as stream:
        for path, arcname in source_entries:
            stream.write(str(path), arcname)
    digest = sha256(archive)
    checksum_path = Path(str(archive) + ".sha256")
    checksum_path.write_text("{}  {}\n".format(digest, archive.name), encoding="ascii")
    print("Return archive: {}".format(archive))
    print("SHA-256: {}".format(digest))


if __name__ == "__main__":
    main()


#!/usr/bin/env python3
"""Produce a non-destructive server readiness and missing-input report."""

from __future__ import print_function

import argparse
import importlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--search-root", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    return parser.parse_args()


def import_status(name):
    try:
        module = importlib.import_module(name)
        return {"ok": True, "version": getattr(module, "__version__", None), "error": None}
    except Exception as exc:
        return {"ok": False, "version": None, "error": "{}: {}".format(type(exc).__name__, exc)}


def main():
    args = parse_args()
    repo = args.repo.resolve()
    search = args.search_root.resolve()
    sys.path.insert(0, str(repo))
    modules = {name: import_status(name) for name in ("numpy", "yaml", "torch", "spconv.pytorch", "HAIS_OP")}
    cuda = {"available": False, "device_count": 0, "device_name": None, "torch_cuda_version": None}
    if modules["torch"]["ok"]:
        import torch
        cuda.update({
            "available": bool(torch.cuda.is_available()),
            "device_count": int(torch.cuda.device_count()),
            "device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "torch_cuda_version": torch.version.cuda,
        })
    checkpoints = []
    for pattern in ("*.pt", "*.pth", "*.ckpt"):
        for path in search.rglob(pattern):
            if path.is_file() and len(checkpoints) < 200:
                checkpoints.append(str(path.resolve()))
    dataset_roots = []
    for marker in search.rglob("val_000.npz"):
        if marker.parent.name == "val":
            candidate = marker.parent.parent
            if (candidate / "test" / "test_000.npz").is_file():
                dataset_roots.append(str(candidate.resolve()))
    try:
        conda = subprocess.run(["conda", "env", "list", "--json"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, check=False)
        conda_envs = json.loads(conda.stdout).get("envs", []) if conda.returncode == 0 else []
    except Exception:
        conda_envs = []
    required_ok = all(modules[name]["ok"] for name in ("numpy", "yaml", "torch", "spconv.pytorch", "HAIS_OP"))
    report = {
        "python_executable": sys.executable,
        "python_version": sys.version,
        "platform": platform.platform(),
        "conda_prefix": os.environ.get("CONDA_PREFIX"),
        "conda_default_env": os.environ.get("CONDA_DEFAULT_ENV"),
        "conda_environments": conda_envs,
        "modules": modules,
        "cuda": cuda,
        "repository": str(repo),
        "config": str(repo / "configs" / "evisseg_evuav.yaml"),
        "checkpoint_candidates": sorted(set(checkpoints)),
        "dataset_candidates": sorted(set(dataset_roots)),
        "ready_for_inference_environment": bool(required_ok and cuda["available"]),
        "missing_for_full_evaluation": [
            item for condition, item in (
                (not required_ok, "Python dependencies or compiled HAIS_OP"),
                (not cuda["available"], "CUDA-visible PyTorch runtime"),
                (not checkpoints, "official pretrained checkpoint (.pt/.pth/.ckpt)"),
                (not dataset_roots, "EV-UAV dataset root containing val/ and test/"),
            ) if condition
        ],
        "recommended_reference_versions": {"python": "3.8", "pytorch": "1.9.1", "cuda_toolkit": "11.3"},
    }
    output = args.work_dir.resolve() / "server_inspection.json"
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print("Inspection report: {}".format(output))


if __name__ == "__main__":
    main()


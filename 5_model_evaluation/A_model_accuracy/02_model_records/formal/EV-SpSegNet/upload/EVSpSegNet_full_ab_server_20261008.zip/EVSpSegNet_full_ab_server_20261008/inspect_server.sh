#!/usr/bin/env bash
set -Eeuo pipefail
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_ZIP="/export01/frshu/experiment/EV-UAV-main.zip"
SEARCH_ROOT="/export01/frshu/experiment"
WORK_DIR="/export01/frshu/experiment/evuav_evaluation_workspace"
PYTHON_BIN="python"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --source-zip) SOURCE_ZIP="$2"; shift 2 ;;
    --search-root) SEARCH_ROOT="$2"; shift 2 ;;
    --work-dir) WORK_DIR="$2"; shift 2 ;;
    --python-bin) PYTHON_BIN="$2"; shift 2 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
mkdir -p "$WORK_DIR"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/verify_package.py"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/prepare_repo.py" --source-zip "$SOURCE_ZIP" --work-dir "$WORK_DIR"
REPO="$(tr -d '\r\n' < "$WORK_DIR/repo_path.txt")"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/inspect_environment.py" --repo "$REPO" --search-root "$SEARCH_ROOT" --work-dir "$WORK_DIR"


import importlib.util
from pathlib import Path
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "profile_complexity.py"
SPEC = importlib.util.spec_from_file_location("profile_complexity", str(SCRIPT))
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class ComplexityAccountingTests(unittest.TestCase):
    def test_mac_plus_ac_identity(self):
        rows = [
            {"events": 10, "dense_macs": 100, "effective_macs": 40, "effective_acs": 0},
            {"events": 20, "dense_macs": 200, "effective_macs": 80, "effective_acs": 0},
        ]
        summary = MODULE.summarize_rows({"total_weight_parameters": 7}, rows)
        self.assertEqual(summary["sequences"], 2)
        self.assertEqual(summary["events"], 30)
        self.assertEqual(summary["dense_macs_per_sequence"], 150.0)
        self.assertEqual(summary["effective_macs_per_sequence"], 60.0)
        self.assertEqual(summary["effective_acs_per_sequence"], 0.0)
        self.assertEqual(
            summary["effective_ops_per_sequence"],
            summary["effective_macs_per_sequence"] + summary["effective_acs_per_sequence"],
        )

    def test_empty_rows_rejected(self):
        with self.assertRaises(ValueError):
            MODULE.summarize_rows({}, [])


if __name__ == "__main__":
    unittest.main()

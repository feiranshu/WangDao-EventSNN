#!/usr/bin/env python3
"""Safely extract an EV-UAV GitHub ZIP and locate the official repository root."""

from __future__ import print_function

import argparse
import hashlib
import json
import os
from pathlib import Path
import zipfile


REQUIRED = ("test.py", "configs/configs.py", "configs/evisseg_evuav.yaml", "dataset/ev_uav.py", "model/evspsegnet.py")


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-zip", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    archive = args.source_zip.resolve()
    if not archive.is_file() or not zipfile.is_zipfile(str(archive)):
        raise SystemExit("Not a valid ZIP archive: {}".format(archive))
    archive_sha = sha256(archive)
    extraction = args.work_dir.resolve() / "official_source" / archive_sha[:16]
    extraction.mkdir(parents=True, exist_ok=True)
    marker = extraction / ".extraction_complete.json"
    if not marker.is_file():
        root_text = str(extraction.resolve())
        with zipfile.ZipFile(str(archive), "r") as stream:
            for member in stream.infolist():
                destination = (extraction / member.filename).resolve()
                if os.path.commonpath([root_text, str(destination)]) != root_text:
                    raise SystemExit("Unsafe path in source ZIP: {}".format(member.filename))
            stream.extractall(str(extraction))
        marker.write_text(json.dumps({"source_zip": str(archive), "source_zip_sha256": archive_sha}, indent=2) + "\n", encoding="utf-8")
    candidates = []
    for test_file in extraction.rglob("test.py"):
        root = test_file.parent
        if all((root / relative).is_file() for relative in REQUIRED):
            candidates.append(root)
    if len(candidates) != 1:
        raise SystemExit("Expected exactly one EV-UAV repository in ZIP, found {}".format(len(candidates)))
    repo = candidates[0].resolve()
    args.work_dir.mkdir(parents=True, exist_ok=True)
    (args.work_dir / "repo_path.txt").write_text(str(repo) + "\n", encoding="utf-8")
    (args.work_dir / "source_archive.json").write_text(
        json.dumps({"path": str(archive), "sha256": archive_sha, "repository_path": str(repo)}, indent=2) + "\n",
        encoding="utf-8",
    )
    print(str(repo))


if __name__ == "__main__":
    main()


#!/usr/bin/env python3
"""Profile EV-SpSegNet B01-B04 on the frozen Validation/Test sequences.

B03 is the dense per-active-output structural MAC count. B04a uses the exact
native sparse-convolution connection pairs; dense Linear/MHA operators keep
their dense MAC count. B04b is zero because EV-SpSegNet is an ANN.
"""

from __future__ import print_function

import argparse
from collections.abc import Mapping
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import sys

import numpy as np


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
INDEX_PATH = PACKAGE_ROOT / "frozen" / "index.json"
ROLE_TO_MODE = {"validation": "val", "test": "test"}
ROLE_TO_OUTPUT = {"validation": "Validation", "test": "Test"}
PROTOCOL = "evspsegnet-official-float-sparse-operator-complexity-v1"


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--provenance", type=Path, required=True)
    parser.add_argument("--roles", nargs="+", choices=("validation", "test"), default=("validation", "test"))
    return parser.parse_args()


def extract_state_dict(payload):
    state = payload
    if isinstance(payload, Mapping):
        for key in ("state_dict", "model_state_dict", "model"):
            candidate = payload.get(key)
            if isinstance(candidate, Mapping):
                state = candidate
                break
    if not isinstance(state, Mapping):
        raise ValueError("checkpoint does not contain a state dictionary")
    keys = list(state.keys())
    if keys and all(str(key).startswith("module.") for key in keys):
        state = {str(key)[7:]: value for key, value in state.items()}
    return state


def product(values):
    result = 1
    for value in values:
        result *= int(value)
    return int(result)


class ComplexityProfiler(object):
    def __init__(self, torch_module, model):
        self.torch = torch_module
        self.model = model
        self.handles = []
        self.rows = []
        self.errors = []
        self._inputs = {}
        self._assign_unique_indice_keys()
        self._register()

    def _is_sparse_conv(self, module):
        name = module.__class__.__name__
        return name in ("SubMConv3d", "SparseConv3d", "SparseInverseConv3d") or (
            name.endswith("Conv3d") and "spconv" in module.__class__.__module__.lower()
        )

    def _assign_unique_indice_keys(self):
        number = 0
        for _, module in self.model.named_modules():
            if self._is_sparse_conv(module) and getattr(module, "indice_key", None) is None:
                number += 1
                module.indice_key = "wangdao_profile_{:04d}".format(number)

    def _register(self):
        nn = self.torch.nn
        for name, module in self.model.named_modules():
            if self._is_sparse_conv(module):
                self.handles.append(module.register_forward_pre_hook(self._sparse_pre(name)))
                self.handles.append(module.register_forward_hook(self._sparse_post(name)))
            elif isinstance(module, nn.MultiheadAttention):
                self.handles.append(module.register_forward_hook(self._mha_hook(name)))
            elif isinstance(module, nn.Linear) and not name.endswith("out_proj"):
                self.handles.append(module.register_forward_hook(self._linear_hook(name)))

    def close(self):
        for handle in self.handles:
            handle.remove()
        self.handles = []

    def reset(self):
        self.rows = []
        self.errors = []
        self._inputs = {}

    def _sparse_pre(self, name):
        def hook(module, inputs):
            if not inputs:
                self.errors.append("{}: missing sparse input".format(name))
                return
            self._inputs[id(module)] = inputs[0]
        return hook

    def _pair_count(self, module, output):
        key = getattr(module, "indice_key", None)
        data = getattr(output, "indice_dict", {}).get(key)
        if data is None:
            raise RuntimeError("indice data not found for key={!r}".format(key))
        pair_num = getattr(data, "indice_pair_num", None)
        if pair_num is not None:
            return int(pair_num.detach().long().sum().item()), "indice_pair_num"
        pair = getattr(data, "pair_bwd" if "Inverse" in module.__class__.__name__ else "pair_fwd", None)
        if pair is None:
            pair = getattr(data, "pair_fwd", None)
        if pair is not None:
            return int((pair.detach() >= 0).long().sum().item()), "implicit_pair_map"
        raise RuntimeError("spconv indice data exposes neither native pair counts nor pair maps")

    def _sparse_post(self, name):
        def hook(module, inputs, output):
            try:
                source = self._inputs.pop(id(module))
                out_sites = int(output.features.shape[0])
                in_channels = int(getattr(module, "in_channels"))
                out_channels = int(getattr(module, "out_channels"))
                groups = int(getattr(module, "groups", 1) or 1)
                kernel_size = getattr(module, "kernel_size")
                if isinstance(kernel_size, int):
                    kernel_size = (kernel_size,)
                kernel_volume = product(kernel_size)
                dense = out_sites * kernel_volume * in_channels * out_channels // groups
                pairs, pair_method = self._pair_count(module, output)
                maximum_pairs = out_sites * kernel_volume
                if pairs < 0 or pairs > maximum_pairs:
                    raise RuntimeError("invalid pair count {} outside [0, {}]".format(pairs, maximum_pairs))
                effective = pairs * in_channels * out_channels // groups
                self.rows.append({
                    "module": name, "type": module.__class__.__name__, "operator": "sparse_conv",
                    "input_sites": int(source.features.shape[0]), "output_sites": out_sites,
                    "kernel_volume": kernel_volume, "valid_pairs": pairs,
                    "pair_count_method": pair_method, "dense_macs": int(dense),
                    "effective_macs": int(effective),
                })
            except Exception as exc:
                self.errors.append("{}: {}".format(name, exc))
        return hook

    def _linear_hook(self, name):
        def hook(module, inputs, output):
            value = inputs[0]
            vectors = int(value.numel() // int(module.in_features))
            macs = vectors * int(module.in_features) * int(module.out_features)
            self.rows.append({
                "module": name, "type": module.__class__.__name__, "operator": "linear",
                "vectors": vectors, "dense_macs": int(macs), "effective_macs": int(macs),
            })
        return hook

    def _mha_hook(self, name):
        def hook(module, inputs, output):
            query = inputs[0]
            key = inputs[1] if len(inputs) > 1 else query
            value = inputs[2] if len(inputs) > 2 else key
            embed = int(module.embed_dim)
            heads = int(module.num_heads)
            if bool(getattr(module, "batch_first", False)):
                batch, q_len = int(query.shape[0]), int(query.shape[1])
                k_len = int(key.shape[1])
            else:
                q_len, batch = int(query.shape[0]), int(query.shape[1])
                k_len = int(key.shape[0])
            q_tokens = batch * q_len
            k_tokens = batch * k_len
            v_tokens = int(value.numel() // embed)
            projections = (q_tokens + k_tokens + v_tokens) * embed * embed
            attention_scores = batch * heads * q_len * k_len * (embed // heads)
            attention_values = attention_scores
            output_projection = q_tokens * embed * embed
            macs = projections + attention_scores + attention_values + output_projection
            self.rows.append({
                "module": name, "type": module.__class__.__name__, "operator": "multihead_attention",
                "batch": batch, "query_length": q_len, "key_length": k_len, "embed_dim": embed,
                "dense_macs": int(macs), "effective_macs": int(macs),
            })
        return hook

    def result(self):
        if self.errors:
            raise RuntimeError("complexity profiling failed:\n" + "\n".join(self.errors))
        if not self.rows:
            raise RuntimeError("complexity profiler recorded no MAC operators")
        return {
            "dense_macs": int(sum(row["dense_macs"] for row in self.rows)),
            "effective_macs": int(sum(row["effective_macs"] for row in self.rows)),
            "effective_acs": 0,
            "operators": list(self.rows),
        }


def model_profile(net):
    parameters = [parameter for parameter in net.parameters() if parameter.requires_grad]
    state = net.state_dict()
    return {
        "total_weight_parameters": int(sum(parameter.numel() for parameter in parameters)),
        "total_tensor_payload_bytes": int(sum(tensor.numel() * tensor.element_size() for tensor in state.values())),
        "trainable_tensor_count": int(len(parameters)),
        "state_tensor_count": int(len(state)),
        "parameter_dtype_bytes": sorted(set(int(parameter.element_size()) for parameter in parameters)),
    }


def summarize_rows(static, rows):
    """Create the B03/B04 split summary from per-sequence operator counts."""
    if not rows:
        raise ValueError("cannot summarize an empty complexity result")
    dense = sum(int(row["dense_macs"]) for row in rows)
    effective_mac = sum(int(row["effective_macs"]) for row in rows)
    effective_ac = sum(int(row.get("effective_acs", 0)) for row in rows)
    sequence_count = len(rows)
    summary = dict(static)
    summary.update({
        "sequences": sequence_count,
        "events": int(sum(int(row["events"]) for row in rows)),
        "total_dense_macs": int(dense),
        "total_effective_macs": int(effective_mac),
        "effective_acs": int(effective_ac),
        "dense_macs_per_sequence": float(dense) / sequence_count,
        "effective_macs_per_sequence": float(effective_mac) / sequence_count,
        "effective_acs_per_sequence": float(effective_ac) / sequence_count,
        "effective_ops_per_sequence": float(effective_mac + effective_ac) / sequence_count,
        "dense_definition": "per active output site: full kernel volume x input channels x output channels; Linear/MHA dense MACs included",
        "effective_definition": "exact native sparse-convolution indice pairs x channel MACs; dense Linear/MHA MACs included; ANN AC=0",
    })
    return summary


def load_prediction(path, expected, checkpoint_sha):
    with np.load(str(path), allow_pickle=False) as archive:
        probability = np.asarray(archive["probabilities"], dtype=np.float32)
        recorded_weight = str(np.asarray(archive["checkpoint_sha256"]).item())
    if probability.shape != (expected,) or recorded_weight != checkpoint_sha:
        raise RuntimeError("prediction/provenance mismatch: {}".format(path))
    return probability


def main():
    args = parse_args()
    repo = args.repo.resolve(); config = args.config.resolve(); checkpoint = args.checkpoint.resolve()
    dataset_root = args.dataset.resolve(); provenance = json.loads(args.provenance.read_text(encoding="utf-8"))
    checkpoint_sha = sha256(checkpoint)
    if checkpoint_sha != provenance["checkpoint_sha256"]:
        raise SystemExit("Checkpoint changed after preflight")
    index = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    records = {item["path"]: item for item in index["files"]}

    os.chdir(str(repo)); sys.path.insert(0, str(repo)); original_argv = list(sys.argv)
    sys.argv = [str(Path(__file__).name), "--config", str(config)]
    try:
        cfg = importlib.import_module("configs.configs").cfg
        EvUAV = importlib.import_module("dataset.ev_uav").EvUAV
        evspsegnet = importlib.import_module("model.evspsegnet").evspsegnet
    finally:
        sys.argv = original_argv

    import torch
    if not torch.cuda.is_available():
        raise SystemExit("CUDA unavailable")
    np.random.seed(0); torch.manual_seed(0); torch.cuda.manual_seed_all(0)
    cfg.root = str(dataset_root); cfg.batch_size = 1; cfg.model_path = str(checkpoint)
    net = evspsegnet(cfg).eval().cuda()
    payload = torch.load(str(checkpoint), map_location="cpu")
    state = extract_state_dict(payload); net.load_state_dict(state, strict=True); del payload, state
    static = model_profile(net)
    profiler = ComplexityProfiler(torch, net)

    all_results = {}
    try:
        for role in args.roles:
            mode = ROLE_TO_MODE[role]; names = list(index["roles"][role])
            ev_dataset = EvUAV(cfg, mode=mode); ev_dataset.file_list = names
            rows = []
            for position, name in enumerate(names, 1):
                record = records[mode + "/" + name]
                sample = ev_dataset[position - 1]; batch = ev_dataset.custom_collate([sample])
                profiler.reset()
                with torch.no_grad():
                    voxel_probability, _ = net(batch["voxel_ev"])
                    p2v_map = batch["p2v_map"].long().cuda()
                    probability = voxel_probability[p2v_map].reshape(-1).detach().cpu().numpy().astype(np.float32, copy=False)
                expected_probability = load_prediction(args.predictions / role / name, int(record["events"]), checkpoint_sha)
                if not np.allclose(probability, expected_probability, rtol=0.0, atol=1e-7):
                    raise RuntimeError("Profiling changed official probabilities: {}".format(name))
                counts = profiler.result()
                rows.append({
                    "sequence": name, "events": int(record["events"]),
                    "dense_macs": counts["dense_macs"], "effective_macs": counts["effective_macs"],
                    "effective_acs": 0, "effective_ops_mac_plus_ac": counts["effective_macs"],
                    "operator_count": len(counts["operators"]),
                    "operators": counts["operators"],
                })
                del sample, batch, voxel_probability, p2v_map
                torch.cuda.empty_cache()
                print("[complexity:{}] {:02d}/24 {}".format(role, position, name), flush=True)
            summary = summarize_rows(static, rows)
            output = args.output / "EV-SpSegNet" / "complexity" / ROLE_TO_OUTPUT[role] / "summary.json"
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps({
                "evaluation_id": "EV-SpSegNet", "model": "EV-SpSegNet",
                "data_split": role, "protocol": PROTOCOL, "numeric_path": "official_float_cuda",
                "source_weights_sha256": checkpoint_sha, "summary": summary, "per_sequence": rows,
            }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            all_results[role] = summary
    finally:
        profiler.close()

    common = args.output / "EV-SpSegNet" / "complexity" / "common" / "model_profile.json"
    common.parent.mkdir(parents=True, exist_ok=True)
    common.write_text(json.dumps({
        "evaluation_id": "EV-SpSegNet", "model": "EV-SpSegNet",
        "protocol": PROTOCOL, "numeric_path": "official_float_cuda",
        "source_weights_sha256": checkpoint_sha, "summary": static,
        "paper_reference": {"reported_parameters": 4000000, "note": "rounded paper value; measured loaded model is authoritative for B01/B02"},
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("Complexity profiling complete: {}".format(common))


if __name__ == "__main__":
    main()

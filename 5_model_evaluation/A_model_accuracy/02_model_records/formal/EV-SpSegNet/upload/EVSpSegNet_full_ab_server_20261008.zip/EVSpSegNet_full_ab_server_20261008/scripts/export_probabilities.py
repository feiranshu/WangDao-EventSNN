#!/usr/bin/env python3
"""Export EV-SpSegNet probabilities in unchanged original-event order."""

from __future__ import print_function

import argparse
from collections.abc import Mapping
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys

import numpy as np


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
INDEX_PATH = PACKAGE_ROOT / "frozen" / "index.json"
ROLE_TO_MODE = {"validation": "val", "test": "test"}


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--provenance", type=Path, required=True)
    parser.add_argument("--roles", nargs="+", choices=("validation", "test"), default=("validation", "test"))
    parser.add_argument("--resume", action="store_true")
    return parser.parse_args()


def extract_state_dict(payload):
    state = payload
    if isinstance(payload, Mapping):
        for key in ("state_dict", "model_state_dict", "model"):
            candidate = payload.get(key)
            if isinstance(candidate, Mapping):
                state = candidate
                break
    if not isinstance(state, Mapping):
        raise ValueError("checkpoint does not contain a state dictionary")
    keys = list(state.keys())
    if keys and all(str(key).startswith("module.") for key in keys):
        state = {str(key)[7:]: value for key, value in state.items()}
    return state


def load_existing(path, expected_count, source_sha, checkpoint_sha):
    try:
        with np.load(str(path), allow_pickle=False) as archive:
            probability = np.asarray(archive["probabilities"], dtype=np.float32)
            recorded_source = str(np.asarray(archive["source_sha256"]).item())
            recorded_weight = str(np.asarray(archive["checkpoint_sha256"]).item())
        valid = (
            probability.shape == (expected_count,)
            and np.all(np.isfinite(probability))
            and np.all((probability >= 0.0) & (probability <= 1.0))
            and recorded_source == source_sha
            and recorded_weight == checkpoint_sha
        )
        return probability if valid else None
    except Exception:
        return None


def atomic_save(path, **arrays):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as stream:
        np.savez_compressed(stream, **arrays)
    os.replace(str(temporary), str(path))


def main():
    args = parse_args()
    repo = args.repo.resolve()
    config = args.config.resolve()
    checkpoint = args.checkpoint.resolve()
    dataset_root = args.dataset.resolve()
    provenance = json.loads(args.provenance.read_text(encoding="utf-8"))
    code_identity = provenance.get("official_repository_commit") or (
        "tree_sha256:" + provenance["official_repository_tree_sha256"]
    )
    checkpoint_sha = sha256(checkpoint)
    if checkpoint_sha != provenance["checkpoint_sha256"]:
        raise SystemExit("Checkpoint changed after preflight")

    index = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    records = {item["path"]: item for item in index["files"]}

    os.chdir(str(repo))
    sys.path.insert(0, str(repo))
    original_argv = list(sys.argv)
    sys.argv = [str(Path(__file__).name), "--config", str(config)]
    try:
        cfg = importlib.import_module("configs.configs").cfg
        EvUAV = importlib.import_module("dataset.ev_uav").EvUAV
        evspsegnet = importlib.import_module("model.evspsegnet").evspsegnet
    finally:
        sys.argv = original_argv

    import torch

    if not torch.cuda.is_available():
        raise SystemExit("CUDA unavailable")
    np.random.seed(0)
    torch.manual_seed(0)
    torch.cuda.manual_seed_all(0)
    cfg.root = str(dataset_root)
    cfg.batch_size = 1
    cfg.model_path = str(checkpoint)
    net = evspsegnet(cfg).eval().cuda()
    checkpoint_payload = torch.load(str(checkpoint), map_location="cpu")
    state = extract_state_dict(checkpoint_payload)
    net.load_state_dict(state, strict=True)
    del checkpoint_payload, state

    manifest_rows = []
    total_sequences = sum(len(index["roles"][role]) for role in args.roles)
    completed = 0
    for role in args.roles:
        mode = ROLE_TO_MODE[role]
        names = list(index["roles"][role])
        ev_dataset = EvUAV(cfg, mode=mode)
        ev_dataset.file_list = names
        for position, name in enumerate(names, 1):
            relative = mode + "/" + name
            source_path = dataset_root / mode / name
            record = records[relative]
            source_sha = sha256(source_path)
            if source_sha != record["sha256"]:
                raise RuntimeError("Dataset changed after preflight: {}".format(source_path))
            output_path = args.output / role / name
            probability = None
            if args.resume and output_path.is_file():
                probability = load_existing(output_path, int(record["events"]), source_sha, checkpoint_sha)
            if probability is None:
                sample = ev_dataset[position - 1]
                batch = ev_dataset.custom_collate([sample])
                with torch.no_grad():
                    voxel_probability, _ = net(batch["voxel_ev"])
                    p2v_map = batch["p2v_map"].long().cuda()
                    probability = (
                        voxel_probability[p2v_map]
                        .reshape(-1)
                        .detach()
                        .cpu()
                        .numpy()
                        .astype(np.float32, copy=False)
                    )
                if probability.shape != (int(record["events"]),):
                    raise RuntimeError(
                        "Event alignment mismatch for {}: expected {}, got {}".format(
                            name, record["events"], probability.shape
                        )
                    )
                if not np.all(np.isfinite(probability)) or not np.all((probability >= 0.0) & (probability <= 1.0)):
                    raise RuntimeError("Invalid probabilities for {}".format(name))
                atomic_save(
                    output_path,
                    probabilities=probability,
                    source_sequence=np.asarray(name),
                    source_sha256=np.asarray(source_sha),
                    checkpoint_sha256=np.asarray(checkpoint_sha),
                    repository_commit=np.asarray(code_identity),
                    event_count=np.asarray(len(probability), dtype=np.int64),
                )
                del sample, batch, voxel_probability, p2v_map
                torch.cuda.empty_cache()
                action = "exported"
            else:
                action = "verified/resumed"
            completed += 1
            row = {
                "role": role,
                "sequence": name,
                "events": int(len(probability)),
                "minimum_probability": float(probability.min()),
                "maximum_probability": float(probability.max()),
                "source_sha256": source_sha,
                "prediction_sha256": sha256(output_path),
                "checkpoint_sha256": checkpoint_sha,
            }
            manifest_rows.append(row)
            print(
                "[export:{}] {:02d}/24 {} ({}, total {}/{})".format(
                    role, position, name, action, completed, total_sequences
                ),
                flush=True,
            )

    manifest = {
        "status": "complete",
        "numeric_path": "official_test_path_preds_indexed_by_p2v_map",
        "probability_alignment": "one float per original event in unchanged sequence order",
        "repository_commit": provenance.get("official_repository_commit"),
        "repository_tree_sha256": provenance["official_repository_tree_sha256"],
        "source_archive_sha256": provenance.get("source_archive_sha256"),
        "checkpoint_sha256": checkpoint_sha,
        "sequence_count": len(manifest_rows),
        "event_count": int(sum(row["events"] for row in manifest_rows)),
        "files": manifest_rows,
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print("Probability export complete: {} sequences".format(len(manifest_rows)))


if __name__ == "__main__":
    main()


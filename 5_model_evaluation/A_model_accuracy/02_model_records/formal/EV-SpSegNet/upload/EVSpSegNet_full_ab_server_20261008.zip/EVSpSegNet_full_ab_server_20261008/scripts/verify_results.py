#!/usr/bin/env python3
"""Cross-check probabilities, summaries and per-sequence result tables."""

from __future__ import print_function

import argparse
import csv
import hashlib
import json
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
INDEX_PATH = PACKAGE_ROOT / "frozen" / "index.json"
ROLE_TO_OUTPUT = {"validation": "Validation", "test": "Test"}
METRICS = ("HOTA", "DetA", "DetRe", "DetPr", "AssA", "AssRe", "AssPr", "LocA")


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work-dir", type=Path, required=True)
    return parser.parse_args()


def main():
    args = parse_args()
    work = args.work_dir.resolve()
    index = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    prediction_manifest_path = work / "predictions" / "manifest.json"
    prediction_manifest = json.loads(prediction_manifest_path.read_text(encoding="utf-8"))
    errors = []
    expected_names = {(role, name) for role in ("validation", "test") for name in index["roles"][role]}
    actual_names = {(item["role"], item["sequence"]) for item in prediction_manifest["files"]}
    if actual_names != expected_names:
        errors.append("prediction manifest does not contain exactly the frozen 48 sequences")
    for item in prediction_manifest["files"]:
        path = work / "predictions" / item["role"] / item["sequence"]
        if not path.is_file() or sha256(path) != item["prediction_sha256"]:
            errors.append("prediction file/hash mismatch: {}".format(path))

    role_reports = {}
    for role in ("validation", "test"):
        event_output = work / "results" / "EV-SpSegNet" / ROLE_TO_OUTPUT[role] / "event_level"
        event_files = {
            name: event_output / name
            for name in ("summary.json", "per_sequence.csv", "threshold_curve.csv", "pr_curve.csv")
        }
        for path in event_files.values():
            if not path.is_file():
                errors.append("missing event-level result file: {}".format(path))
        event_report = {}
        if all(path.is_file() for path in event_files.values()):
            event_summary = json.loads(event_files["summary.json"].read_text(encoding="utf-8"))
            event_working = event_summary.get("working_point", {})
            if float(event_working.get("threshold", -1)) != 0.90:
                errors.append("event threshold is not frozen at 0.90: {}".format(event_files["summary.json"]))
            if int(event_summary.get("evaluation", {}).get("sequence_count", -1)) != 24:
                errors.append("event summary does not contain 24 sequences: {}".format(event_files["summary.json"]))
            with event_files["per_sequence.csv"].open("r", encoding="utf-8-sig", newline="") as stream:
                event_rows = list(csv.DictReader(stream))
            if [row["file"] for row in event_rows] != list(index["roles"][role]):
                errors.append("event per-sequence order/content mismatch: {}".format(event_files["per_sequence.csv"]))
            with event_files["threshold_curve.csv"].open("r", encoding="utf-8-sig", newline="") as stream:
                threshold_rows = list(csv.DictReader(stream))
            if len(threshold_rows) != 19:
                errors.append("event threshold curve must contain 19 thresholds: {}".format(event_files["threshold_curve.csv"]))
            with event_files["pr_curve.csv"].open("r", encoding="utf-8-sig", newline="") as stream:
                pr_count = sum(1 for _ in csv.DictReader(stream))
            if pr_count <= 0:
                errors.append("empty PR curve: {}".format(event_files["pr_curve.csv"]))
            overall_event = event_working.get("overall", {}).get("event", {})
            for metric in ("iou", "precision", "recall", "f1"):
                value = overall_event.get(metric)
                if not isinstance(value, (int, float)) or not 0.0 <= float(value) <= 1.0:
                    errors.append("invalid event {}: {}".format(metric, event_files["summary.json"]))
            ap = event_working.get("average_precision")
            if not isinstance(ap, (int, float)) or not 0.0 <= float(ap) <= 1.0:
                errors.append("invalid Event AP: {}".format(event_files["summary.json"]))
            event_report = {
                "summary_sha256": sha256(event_files["summary.json"]),
                "per_sequence_sha256": sha256(event_files["per_sequence.csv"]),
                "threshold_curve_sha256": sha256(event_files["threshold_curve.csv"]),
                "pr_curve_sha256": sha256(event_files["pr_curve.csv"]),
                "sequence_count": len(event_rows),
                "pr_rows": pr_count,
                "average_precision": ap,
                "working_point": event_working.get("overall"),
            }
        output = work / "results" / "EV-SpSegNet" / ROLE_TO_OUTPUT[role] / "target_track_level"
        summary_path = output / "summary.json"
        sequence_path = output / "per_sequence.csv"
        detections_path = output / "detections.csv"
        for path in (summary_path, sequence_path, detections_path):
            if not path.is_file():
                errors.append("missing result file: {}".format(path))
        if not summary_path.is_file() or not sequence_path.is_file() or not detections_path.is_file():
            continue
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        if summary.get("status") != "complete" or summary.get("sequence_count") != 24:
            errors.append("incomplete summary: {}".format(summary_path))
        if float(summary.get("threshold", -1)) != 0.90:
            errors.append("threshold is not frozen at 0.90: {}".format(summary_path))
        expected_events = int(index["summaries"]["val" if role == "validation" else "test"]["events"])
        if int(summary.get("events", -1)) != expected_events:
            errors.append("event total mismatch: {}".format(summary_path))
        averaged = summary.get("metrics", {}).get("averaged", {})
        for metric in METRICS:
            value = averaged.get(metric)
            if not isinstance(value, (int, float)) or not 0.0 <= float(value) <= 1.0:
                errors.append("invalid {} in {}".format(metric, summary_path))
        with sequence_path.open("r", encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        names = [row["sequence"] for row in rows]
        if names != list(index["roles"][role]):
            errors.append("per-sequence order/content mismatch: {}".format(sequence_path))
        with detections_path.open("r", encoding="utf-8-sig", newline="") as stream:
            detection_count = sum(1 for _ in csv.DictReader(stream))
        if detection_count <= 0:
            errors.append("empty detections table: {}".format(detections_path))
        role_reports[role] = {
            "event_level": event_report,
            "target_track_level": {
            "summary_sha256": sha256(summary_path),
            "per_sequence_sha256": sha256(sequence_path),
            "detections_sha256": sha256(detections_path),
            "sequence_count": len(rows),
            "detection_rows": detection_count,
            "events": summary.get("events"),
            "metrics": averaged,
            },
        }

        complexity = work / "results" / "EV-SpSegNet" / "complexity" / ROLE_TO_OUTPUT[role] / "summary.json"
        if not complexity.is_file():
            errors.append("missing complexity result: {}".format(complexity))
        else:
            payload = json.loads(complexity.read_text(encoding="utf-8"))
            summary_values = payload.get("summary", {})
            if int(summary_values.get("sequences", -1)) != 24:
                errors.append("complexity summary does not contain 24 sequences: {}".format(complexity))
            expected_events = int(index["summaries"]["val" if role == "validation" else "test"]["events"])
            if int(summary_values.get("events", -1)) != expected_events:
                errors.append("complexity event total mismatch: {}".format(complexity))
            for key in ("dense_macs_per_sequence", "effective_macs_per_sequence", "effective_ops_per_sequence"):
                if not isinstance(summary_values.get(key), (int, float)) or float(summary_values[key]) <= 0:
                    errors.append("invalid complexity {}: {}".format(key, complexity))
            ac = float(summary_values.get("effective_acs_per_sequence", -1))
            mac = float(summary_values.get("effective_macs_per_sequence", -1))
            total = float(summary_values.get("effective_ops_per_sequence", -1))
            if ac != 0.0 or abs(total - (mac + ac)) > 1e-6:
                errors.append("B04c identity or ANN AC check failed: {}".format(complexity))
            role_reports[role]["complexity"] = {
                "summary_sha256": sha256(complexity),
                "sequences": summary_values.get("sequences"),
                "events": summary_values.get("events"),
                "dense_macs_per_sequence": summary_values.get("dense_macs_per_sequence"),
                "effective_macs_per_sequence": summary_values.get("effective_macs_per_sequence"),
                "effective_acs_per_sequence": summary_values.get("effective_acs_per_sequence"),
                "effective_ops_per_sequence": summary_values.get("effective_ops_per_sequence"),
            }

    common_profile = work / "results" / "EV-SpSegNet" / "complexity" / "common" / "model_profile.json"
    if not common_profile.is_file():
        errors.append("missing common complexity profile: {}".format(common_profile))
    else:
        common_data = json.loads(common_profile.read_text(encoding="utf-8"))
        common_summary = common_data.get("summary", {})
        if int(common_summary.get("total_weight_parameters", 0)) <= 0:
            errors.append("invalid B01 parameter count: {}".format(common_profile))
        if int(common_summary.get("total_tensor_payload_bytes", 0)) <= 0:
            errors.append("invalid B02 tensor payload: {}".format(common_profile))

    report = {
        "status": "failed" if errors else "passed",
        "errors": errors,
        "probability_manifest_sha256": sha256(prediction_manifest_path),
        "prediction_sequences": len(actual_names),
        "roles": role_reports,
    }
    report_path = work / "verification_report.json"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if errors:
        raise SystemExit("Result verification failed:\n" + "\n".join(errors))
    print("Result verification PASSED: A event/track metrics + B complexity, 48 sequences")


if __name__ == "__main__":
    main()


#!/usr/bin/env python3
"""Validate CUDA, official code, checkpoint and frozen EV-UAV data."""

from __future__ import print_function

import argparse
import datetime as dt
import hashlib
import json
import platform
from pathlib import Path
import subprocess
import sys


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
INDEX_PATH = PACKAGE_ROOT / "frozen" / "index.json"
REQUIRED_REPO_FILES = (
    "test.py",
    "configs/configs.py",
    "dataset/ev_uav.py",
    "dataset/basedataset.py",
    "model/evspsegnet.py",
)


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tree_fingerprint(root):
    digest = hashlib.sha256()
    for path in sorted(item for item in root.rglob("*") if item.is_file() and ".git" not in item.parts and "__pycache__" not in item.parts):
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        digest.update(bytes.fromhex(sha256(path)))
    return digest.hexdigest()


def git_output(repo, *args):
    process = subprocess.run(
        ["git", "-C", str(repo)] + list(args),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True,
        check=False,
    )
    if process.returncode != 0:
        raise RuntimeError("git {} failed: {}".format(" ".join(args), process.stderr.strip()))
    return process.stdout.strip()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--source-archive", type=Path)
    return parser.parse_args()


def main():
    args = parse_args()
    repo = args.repo.resolve()
    config = args.config.resolve()
    checkpoint = args.checkpoint.resolve()
    dataset = args.dataset.resolve()
    for relative in REQUIRED_REPO_FILES:
        path = repo / relative
        if not path.is_file():
            raise SystemExit("Official repository file is missing: {}".format(path))
    for label, path in (("config", config), ("checkpoint", checkpoint), ("dataset", dataset)):
        if not path.exists():
            raise SystemExit("{} path does not exist: {}".format(label, path))

    try:
        import numpy as np
        import torch
        import yaml  # noqa: F401
        import spconv.pytorch as spconv  # noqa: F401
        sys.path.insert(0, str(repo))
        import HAIS_OP  # noqa: F401
    except Exception as exc:
        raise SystemExit("Required EV-UAV runtime dependency is unavailable: {}".format(exc))
    if not torch.cuda.is_available():
        raise SystemExit("CUDA unavailable in the active Python environment")

    index = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    records = {item["path"]: item for item in index["files"]}
    role_to_split = {"validation": "val", "test": "test"}
    checked = []
    for role, split in role_to_split.items():
        names = index["roles"][role]
        if len(names) != 24:
            raise SystemExit("Frozen index does not contain 24 {} sequences".format(role))
        for number, name in enumerate(names, 1):
            relative = split + "/" + name
            path = dataset / split / name
            if not path.is_file():
                raise SystemExit("Dataset file is missing: {}".format(path))
            actual = sha256(path)
            expected = records[relative]["sha256"]
            if actual != expected:
                raise SystemExit("Dataset hash mismatch: {} expected={} actual={}".format(path, expected, actual))
            checked.append({"role": role, "name": name, "sha256": actual, "events": records[relative]["events"]})
            print("[preflight:{}] {:02d}/24 {}".format(role, number, name), flush=True)

    if (repo / ".git").exists():
        commit = git_output(repo, "rev-parse", "HEAD")
        status = git_output(repo, "status", "--porcelain")
        try:
            remote = git_output(repo, "config", "--get", "remote.origin.url")
        except RuntimeError:
            remote = "https://github.com/ChenYichen9527/Ev-UAV"
    else:
        commit = None
        status = ""
        remote = "https://github.com/ChenYichen9527/Ev-UAV"
    source_archive = args.source_archive.resolve() if args.source_archive else None
    if source_archive is not None and not source_archive.is_file():
        raise SystemExit("source archive does not exist: {}".format(source_archive))
    package_manifest = PACKAGE_ROOT / "PACKAGE_MANIFEST.json"
    payload = {
        "status": "ready",
        "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "numeric_path": "official_float_cuda_export_via_preds_p2v_map",
        "official_repository_path": str(repo),
        "official_repository_remote": remote,
        "official_repository_commit": commit,
        "official_repository_tree_sha256": tree_fingerprint(repo),
        "official_repository_dirty": bool(status),
        "official_repository_status_porcelain": status.splitlines(),
        "source_archive_path": None if source_archive is None else str(source_archive),
        "source_archive_sha256": None if source_archive is None else sha256(source_archive),
        "config_path": str(config),
        "config_sha256": sha256(config),
        "checkpoint_path": str(checkpoint),
        "checkpoint_sha256": sha256(checkpoint),
        "dataset_path": str(dataset),
        "data_index_sha256": sha256(INDEX_PATH),
        "dataset_fingerprint": index.get("dataset_fingerprint"),
        "verified_sequences": len(checked),
        "verified_events": int(sum(item["events"] for item in checked)),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy_version": np.__version__,
        "torch_version": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "cuda_device_count": torch.cuda.device_count(),
        "cuda_device_name": torch.cuda.get_device_name(0),
        "package_manifest_sha256": sha256(package_manifest),
        "threshold": 0.90,
    }
    args.work_dir.mkdir(parents=True, exist_ok=True)
    output = args.work_dir / "provenance.json"
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("Preflight OK. Provenance written to {}".format(output))
    if status:
        print("WARNING: official repository has local modifications; exact status is recorded in provenance.json")


if __name__ == "__main__":
    main()


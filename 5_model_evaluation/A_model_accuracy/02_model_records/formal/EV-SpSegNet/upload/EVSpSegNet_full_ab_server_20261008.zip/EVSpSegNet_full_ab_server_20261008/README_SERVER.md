# EV-SpSegNet A+B 完整补测服务器包

本包适配服务器上只有 `/export01/frshu/experiment/EV-UAV-main.zip` 的状态。它会在独立工作区安全解压官方工程，不修改原 ZIP，也不假定源码已经展开。

## 为什么仍需服务器实测

EV-UAV 论文表 2 只直接给出 EV-SpSegNet 的 Test Event IoU 55.18%、ACC 65.02%、Pd 77.53%、Fa 1.63×10^-4、约 4.0M 参数和 35.9 ms 运行时间。论文和官方 `test.py` 没有给出 Validation 全套结果、Event AP/Precision/F1/密度分组/事件计数、目标轨迹 HOTA 分项、精确模型存储量或 B03/B04 运算量。因此不能用论文值推算缺项。

## 本包输出

一次官方 CUDA 浮点推理导出逐事件概率，并完成：

1. A01–A13 事件级指标：Validation 与 Test 分开计算；模型阈值固定 0.90。
2. A14–A22 可观测事件轨迹 HOTA 指标：Validation 与 Test 分开计算。
3. B01/B02：严格加载官方 checkpoint 后的可训练参数量与 `state_dict` tensor payload 字节数。
4. B03：每个实际输出活跃位置按完整卷积核连接计算的结构稠密 MAC；Validation/Test 分开统计。
5. B04a：按 spconv 原生有效 indice pair 统计的实际稀疏 MAC；B04b 为 ANN 的 0 AC；B04c 严格等于 B04a+B04b。

B03 与 B04 使用相同序列、事件和算子边界。脚本还会在开启复杂度 hook 后重新核对逐事件概率，确保统计没有改变模型输出。

## 第一步：检查环境

```bash
cd /export01/frshu/experiment
unzip EVSpSegNet_full_ab_server_20261008.zip
cd EVSpSegNet_full_ab_server_20261008
conda activate evuav
bash inspect_server.sh
```

检查器只发现和记录环境，不安装依赖、不修改环境。重点查看工作区中的 `server_inspection.json`：

- `ready_for_inference_environment` 是否为 `true`；
- 是否找到官方预训练 checkpoint；
- 是否找到同时包含 `val/`、`test/` 的 EV-UAV 数据集；
- `missing_for_full_evaluation` 是否为空。

官方参考环境为 Python 3.8、PyTorch 1.9.1、CUDA 11.3。最终以 `spconv.pytorch`、`HAIS_OP` 可导入且 CUDA 推理成功为准。

## 第二步：运行 A+B 完整评测

```bash
bash run_all.sh \
  --checkpoint /absolute/path/to/best_iou_seed37.pt \
  --dataset /absolute/path/to/EV-UAV-dataset
```

完整参数形式：

```bash
bash run_all.sh \
  --source-zip /export01/frshu/experiment/EV-UAV-main.zip \
  --checkpoint /absolute/path/to/best_iou_seed37.pt \
  --dataset /absolute/path/to/EV-UAV-dataset \
  --work-dir /export01/frshu/experiment/evuav_evaluation_workspace
```

默认配置为官方 `configs/evisseg_evuav.yaml`；运行时只在内存中覆盖数据根目录、权重路径和 `batch_size=1`。如需另一个配置，可传 `--config /absolute/path/to/config.yaml`。

## 冻结协议

- 正式 `evaluation_id`：`EV-SpSegNet`。
- 数值路径：官方 EV-SpSegNet float CUDA，checkpoint 必须严格加载。
- A 阈值：0.90；Validation/Test 禁止调参。
- 逐事件概率：官方 `preds[p2v_map]`，保持原事件顺序。
- 事件协议：`evuav-33e2aff-official-compatible-v1+step3-density-20000`。
- 轨迹协议：`evuav-observable-event-track-hota-v1`；50 ms 窗口、3 px 聚类半径、20 px/50 ms 关联门限、状态保留 20 窗。
- 复杂度协议：`evspsegnet-official-float-sparse-operator-complexity-v1`。
- B02 是加载后 `state_dict` 的 tensor payload，不是压缩 checkpoint 文件大小。
- B04b 必须单列为 0；正式对比只用 B04c 与 B03 比较。

## 输出目录

```text
results/EV-SpSegNet/
├── Validation/
│   ├── event_level/{summary.json,per_sequence.csv,threshold_curve.csv,pr_curve.csv}
│   └── target_track_level/{summary.json,per_sequence.csv,detections.csv}
├── Test/
│   ├── event_level/{summary.json,per_sequence.csv,threshold_curve.csv,pr_curve.csv}
│   └── target_track_level/{summary.json,per_sequence.csv,detections.csv}
└── complexity/
    ├── common/model_profile.json
    ├── Validation/summary.json
    └── Test/summary.json
```

完成后下载：

- `EVSpSegNet_full_ab_return_*.zip`
- 同名 `.sha256`

回到本地项目后运行：

```bash
python 1_H2_model_improvement/implementation/software/scripts/import_ev_spsegnet_results.py \
  /path/to/EVSpSegNet_full_ab_return_YYYYMMDD_HHMMSS.zip
```

导入器会验证回传清单和全部文件 SHA-256，写入 A/B 正式模型源记录，更新模型注册表的权重哈希，再重建所有分指标 CSV 和完整性表。

## 常见阻塞

- 源码 ZIP 不含预训练权重；需从官方发布位置取得 `best_iou_seed37.pt`。
- 源码 ZIP 不含完整数据集；需准备 `val/*.npz` 与 `test/*.npz`。
- `HAIS_OP`/`spconv` 失败：按官方 README 在同一环境安装 spconv 并编译 `lib/hais_ops`。
- 冻结数据哈希不一致：不可绕过，否则无法与 H2/H2-plus 公平比较。
- 原生 spconv indice pair 不可读取：B04 统计会明确失败，不会退化成估算值。

GitHub 的 `main.zip` 通常没有 `.git` 元数据。脚本会记录源 ZIP SHA-256 和解压代码树 SHA-256；只有实际存在 `.git` 时才记录 commit，不会伪造提交号。

官方工程：<https://github.com/ChenYichen9527/EV-UAV>。

#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="python"
SOURCE_ZIP="/export01/frshu/experiment/EV-UAV-main.zip"
CONFIG=""
CHECKPOINT=""
DATASET=""
WORK_DIR="/export01/frshu/experiment/evuav_evaluation_workspace"

usage() {
  sed -n '1,180p' "$PACKAGE_DIR/README_SERVER.md"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --source-zip) SOURCE_ZIP="$2"; shift 2 ;;
    --config) CONFIG="$2"; shift 2 ;;
    --checkpoint) CHECKPOINT="$2"; shift 2 ;;
    --dataset) DATASET="$2"; shift 2 ;;
    --work-dir) WORK_DIR="$2"; shift 2 ;;
    --python-bin) PYTHON_BIN="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ -z "$CHECKPOINT" || -z "$DATASET" ]]; then
  echo "Missing --checkpoint or --dataset. Run inspect_server.sh first to locate/check them." >&2
  usage >&2
  exit 2
fi

mkdir -p "$WORK_DIR"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/verify_package.py"
"$PYTHON_BIN" -m unittest discover -s "$PACKAGE_DIR/tests" -v
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/prepare_repo.py" \
  --source-zip "$SOURCE_ZIP" --work-dir "$WORK_DIR"
REPO="$(tr -d '\r\n' < "$WORK_DIR/repo_path.txt")"
if [[ -z "$CONFIG" ]]; then
  CONFIG="$REPO/configs/evisseg_evuav.yaml"
fi
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/inspect_environment.py" \
  --repo "$REPO" --search-root "/export01/frshu/experiment" --work-dir "$WORK_DIR"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/preflight.py" \
  --repo "$REPO" --config "$CONFIG" --checkpoint "$CHECKPOINT" \
  --dataset "$DATASET" --work-dir "$WORK_DIR" --source-archive "$SOURCE_ZIP"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/export_probabilities.py" \
  --repo "$REPO" --config "$CONFIG" --checkpoint "$CHECKPOINT" \
  --dataset "$DATASET" --output "$WORK_DIR/predictions" \
  --provenance "$WORK_DIR/provenance.json" --roles validation test --resume
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/evaluate_events.py" \
  --dataset "$DATASET" --predictions "$WORK_DIR/predictions" \
  --output "$WORK_DIR/results" --provenance "$WORK_DIR/provenance.json" \
  --roles validation test
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/evaluate_tracks.py" \
  --dataset "$DATASET" --predictions "$WORK_DIR/predictions" \
  --output "$WORK_DIR/results" --provenance "$WORK_DIR/provenance.json" \
  --roles validation test
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/profile_complexity.py" \
  --repo "$REPO" --config "$CONFIG" --checkpoint "$CHECKPOINT" \
  --dataset "$DATASET" --predictions "$WORK_DIR/predictions" \
  --output "$WORK_DIR/results" --provenance "$WORK_DIR/provenance.json" \
  --roles validation test
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/verify_results.py" --work-dir "$WORK_DIR"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/pack_return.py" --work-dir "$WORK_DIR"

echo "All stages completed successfully."
echo "Download EVSpSegNet_full_ab_return_*.zip and its .sha256 from:"
echo "$WORK_DIR"


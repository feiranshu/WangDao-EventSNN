#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="python"
REPO="/export01/frshu/experiment/EMS-YOLO"
CHECKPOINT="/export01/frshu/experiment/EMS-YOLO/runs/train/exp3/weights/best.pt"
RAW_DATASET=""
WORK_DIR="/export01/frshu/experiment/ems_yolo_evaluation_workspace"
DEVICE="0"

usage() { sed -n '1,240p' "$PACKAGE_DIR/README_SERVER.md"; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo) REPO="$2"; shift 2 ;;
    --checkpoint) CHECKPOINT="$2"; shift 2 ;;
    --raw-dataset) RAW_DATASET="$2"; shift 2 ;;
    --work-dir) WORK_DIR="$2"; shift 2 ;;
    --device) DEVICE="$2"; shift 2 ;;
    --python-bin) PYTHON_BIN="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ -z "$RAW_DATASET" ]]; then
  echo "Missing --raw-dataset. It must contain the frozen EV-UAV val/ and test/ NPZ files." >&2
  usage >&2
  exit 2
fi

mkdir -p "$WORK_DIR"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/verify_package.py"
"$PYTHON_BIN" -m unittest discover -s "$PACKAGE_DIR/tests" -v
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/inspect_environment.py" \
  --repo "$REPO" --checkpoint "$CHECKPOINT" --raw-dataset "$RAW_DATASET" \
  --work-dir "$WORK_DIR"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/preflight.py" \
  --repo "$REPO" --checkpoint "$CHECKPOINT" --raw-dataset "$RAW_DATASET" \
  --work-dir "$WORK_DIR"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/export_and_profile.py" \
  --repo "$REPO" --checkpoint "$CHECKPOINT" --raw-dataset "$RAW_DATASET" \
  --work-dir "$WORK_DIR" --device "$DEVICE" --roles validation test
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/evaluate_events.py" \
  --dataset "$RAW_DATASET" --predictions "$WORK_DIR/predictions" \
  --output "$WORK_DIR/results" --provenance "$WORK_DIR/provenance.json" \
  --roles validation test
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/evaluate_tracks.py" \
  --dataset "$RAW_DATASET" --predictions "$WORK_DIR/predictions" \
  --output "$WORK_DIR/results" --provenance "$WORK_DIR/provenance.json" \
  --roles validation test
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/verify_results.py" --work-dir "$WORK_DIR"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/pack_return.py" --work-dir "$WORK_DIR"

echo "All stages completed successfully."
echo "Download EMS_YOLO_full_ab_return_*.zip and its .sha256 from:"
echo "$WORK_DIR"

#!/usr/bin/env python3
"""Verify the extracted package before any CUDA inference is started."""

from __future__ import print_function

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "PACKAGE_MANIFEST.json"


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    if not MANIFEST.is_file():
        raise SystemExit("PACKAGE_MANIFEST.json is missing")
    payload = json.loads(MANIFEST.read_text(encoding="utf-8"))
    errors = []
    for item in payload["files"]:
        path = ROOT / item["path"]
        if not path.is_file():
            errors.append("missing: " + item["path"])
            continue
        actual = sha256(path)
        if actual != item["sha256"]:
            errors.append("hash mismatch: {} expected={} actual={}".format(item["path"], item["sha256"], actual))
    if errors:
        raise SystemExit("Package integrity verification failed:\n" + "\n".join(errors))
    print("Package integrity OK: {} files".format(len(payload["files"])))


if __name__ == "__main__":
    main()


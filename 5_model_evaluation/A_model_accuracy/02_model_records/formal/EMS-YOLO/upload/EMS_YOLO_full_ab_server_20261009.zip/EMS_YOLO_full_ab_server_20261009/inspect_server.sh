#!/usr/bin/env bash
set -Eeuo pipefail
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="/export01/frshu/experiment/EMS-YOLO"
CHECKPOINT="/export01/frshu/experiment/EMS-YOLO/runs/train/exp3/weights/best.pt"
RAW_DATASET=""
WORK_DIR="/export01/frshu/experiment/ems_yolo_evaluation_workspace"
PYTHON_BIN="python"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo) REPO="$2"; shift 2 ;;
    --checkpoint) CHECKPOINT="$2"; shift 2 ;;
    --raw-dataset) RAW_DATASET="$2"; shift 2 ;;
    --work-dir) WORK_DIR="$2"; shift 2 ;;
    --python-bin) PYTHON_BIN="$2"; shift 2 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
if [[ -z "$RAW_DATASET" ]]; then
  echo "Missing --raw-dataset" >&2
  exit 2
fi
mkdir -p "$WORK_DIR"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/verify_package.py"
"$PYTHON_BIN" "$PACKAGE_DIR/scripts/inspect_environment.py" \
  --repo "$REPO" --checkpoint "$CHECKPOINT" --raw-dataset "$RAW_DATASET" \
  --work-dir "$WORK_DIR"

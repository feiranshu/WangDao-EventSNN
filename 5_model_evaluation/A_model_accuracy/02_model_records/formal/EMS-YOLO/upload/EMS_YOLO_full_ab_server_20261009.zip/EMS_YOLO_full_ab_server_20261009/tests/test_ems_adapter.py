import importlib.util
from pathlib import Path
import unittest

import numpy as np


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "export_and_profile.py"
SPEC = importlib.util.spec_from_file_location("export_and_profile", str(SCRIPT))
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class EMSAdapterTests(unittest.TestCase):
    def test_box_probability_assignment_and_time_windows(self):
        events = np.zeros(4, dtype=[("t", "f8")]); events["t"] = [0.0, 149.999, 250.0, 7999.0]
        norm = np.zeros((4, 6), dtype=np.float64); norm[:, :2] = [[0, 0], [0.1, 0.1], [0.1, 0.1], [0.99, 0.99]]
        x_pre = int(0.1 * MODULE.PREPROCESS_WIDTH); y_pre = int(0.1 * MODULE.PREPROCESS_HEIGHT)
        x = (x_pre + 0.5) * MODULE.MODEL_WIDTH / MODULE.PREPROCESS_WIDTH - 0.5
        y = (y_pre + 0.5) * MODULE.MODEL_HEIGHT / MODULE.PREPROCESS_HEIGHT - 0.5
        windows = [
            {"start_ms": 0.0, "boxes": [[x - 1, y - 1, x + 1, y + 1, 0.6]]},
            {"start_ms": 100.0, "boxes": [[x - 1, y - 1, x + 1, y + 1, 0.8]]},
            {"start_ms": 7900.0, "boxes": [[0, 0, MODULE.MODEL_WIDTH, MODULE.MODEL_HEIGHT, 0.2]]},
        ]
        values = MODULE.boxes_to_event_probabilities(events, norm, windows)
        np.testing.assert_allclose(values, [0.0, 0.8, 0.8, 0.2], rtol=0, atol=1e-7)

    def test_overlapping_boxes_take_maximum(self):
        events = np.zeros(1, dtype=[("t", "f8")]); events["t"] = [10.0]
        norm = np.zeros((1, 6), dtype=np.float64); norm[0, :2] = [0.5, 0.5]
        x_pre = int(0.5 * MODULE.PREPROCESS_WIDTH); y_pre = int(0.5 * MODULE.PREPROCESS_HEIGHT)
        x = (x_pre + 0.5) * MODULE.MODEL_WIDTH / MODULE.PREPROCESS_WIDTH - 0.5
        y = (y_pre + 0.5) * MODULE.MODEL_HEIGHT / MODULE.PREPROCESS_HEIGHT - 0.5
        windows = [{"start_ms": 0.0, "boxes": [[x - 1, y - 1, x + 1, y + 1, 0.3], [x - 2, y - 2, x + 2, y + 2, 0.9]]}]
        self.assertAlmostEqual(float(MODULE.boxes_to_event_probabilities(events, norm, windows)[0]), 0.9, places=6)

    def test_renderer_does_not_read_labels_or_names(self):
        events = np.zeros(2, dtype=[("t", "f8")]); events["t"] = [0.0, 50.0]
        norm = np.asarray([[0.5, 0.5, 0, 1, 0, 0], [0.25, 0.25, 0, 0, 1, 7]], dtype=np.float64)
        changed = norm.copy(); changed[:, 4:] = [[1, 9], [0, 3]]
        np.testing.assert_array_equal(MODULE.render_window(events, norm, 0.0), MODULE.render_window(events, changed, 0.0))

    def test_mac_plus_ac_identity(self):
        rows = [
            {"events": 10, "samples": 2, "dense_macs": 100, "effective_macs": 40, "effective_acs": 30},
            {"events": 20, "samples": 3, "dense_macs": 200, "effective_macs": 80, "effective_acs": 50},
        ]
        summary = MODULE.summarize({"total_weight_parameters": 7}, rows)
        self.assertEqual(summary["dense_macs_per_sequence"], 150.0)
        self.assertEqual(summary["effective_macs_per_sequence"], 60.0)
        self.assertEqual(summary["effective_acs_per_sequence"], 40.0)
        self.assertEqual(summary["effective_ops_per_sequence"], 100.0)

    def test_empty_rows_rejected(self):
        with self.assertRaises(ValueError):
            MODULE.summarize({}, [])


if __name__ == "__main__":
    unittest.main()

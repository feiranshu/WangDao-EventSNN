from pathlib import Path
import sys
import unittest

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from lib.phase1_metrics import (  # noqa: E402
    event_counts, event_summary, localization_counts, localization_summary,
)


class EventMetricTests(unittest.TestCase):
    def test_event_counts_and_no_tn_primary_metrics(self):
        counts = event_counts(
            np.asarray([1, 1, 0, 0]),
            np.asarray([0.9, 0.1, 0.8, 0.2]),
            0.5,
        )
        self.assertEqual(counts, {"tp": 1, "fp": 1, "fn": 1, "tn": 1})
        summary = event_summary(counts)
        self.assertEqual(summary["iou"], 1 / 3)
        self.assertEqual(summary["precision"], 0.5)
        self.assertEqual(summary["recall"], 0.5)

    def test_official_localization_perfect_target(self):
        loc = np.asarray([[10, 10, 1], [11, 10, 2], [30, 30, 3]], dtype=float)
        labels = np.asarray([1, 1, 0])
        identities = np.asarray([7, 7, 0])
        probabilities = np.asarray([0.95, 0.99, 0.01])
        counts = localization_counts(loc, labels, identities, probabilities, 0.9)
        values = localization_summary(counts)
        self.assertEqual(values["targets"], 1)
        self.assertEqual(values["correct_targets"], 1)
        self.assertEqual(values["pd"], 1.0)
        self.assertEqual(values["false_components"], 0)

    def test_false_component_increases_fa(self):
        loc = np.asarray([[10, 10, 1], [20, 20, 101]], dtype=float)
        labels = np.asarray([1, 0])
        identities = np.asarray([2, 0])
        probabilities = np.asarray([0.95, 0.95])
        values = localization_summary(
            localization_counts(loc, labels, identities, probabilities, 0.9)
        )
        self.assertEqual(values["false_components"], 1)
        self.assertGreater(values["fa"], 0.0)


if __name__ == "__main__":
    unittest.main()


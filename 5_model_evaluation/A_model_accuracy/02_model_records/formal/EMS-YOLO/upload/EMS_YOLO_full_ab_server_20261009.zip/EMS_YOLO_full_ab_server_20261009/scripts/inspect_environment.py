#!/usr/bin/env python3
"""Inspect the EMS-YOLO server environment without changing it."""

from __future__ import print_function

import argparse
import importlib
import json
from pathlib import Path
import platform
import sys


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--raw-dataset", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    return parser.parse_args()


def import_status(name):
    try:
        module = importlib.import_module(name)
        return {"available": True, "version": getattr(module, "__version__", "unknown")}
    except Exception as exc:
        return {"available": False, "error": "{}: {}".format(type(exc).__name__, exc)}


def main():
    args = parse_args()
    args.work_dir.mkdir(parents=True, exist_ok=True)
    modules = {name: import_status(name) for name in ("numpy", "yaml", "cv2", "torch")}
    cuda = {"available": False}
    if modules["torch"]["available"]:
        import torch
        cuda = {
            "available": bool(torch.cuda.is_available()),
            "torch_cuda": torch.version.cuda,
            "device_count": int(torch.cuda.device_count()),
            "devices": [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())],
        }
    repo_files = ["models/common.py", "models/yolo.py", "models/resnet34-cat.yaml", "utils/general.py"]
    raw_splits = {split: (args.raw_dataset / split).is_dir() for split in ("train", "val", "test")}
    report = {
        "python": sys.version,
        "platform": platform.platform(),
        "repo": str(args.repo.resolve()),
        "checkpoint": {"path": str(args.checkpoint.resolve()), "exists": args.checkpoint.is_file()},
        "raw_dataset": {"path": str(args.raw_dataset.resolve()), "splits": raw_splits},
        "modules": modules,
        "cuda": cuda,
        "repo_files": {name: (args.repo / name).is_file() for name in repo_files},
        "input_generation": "from frozen raw NPZ; 250 ms window, 100 ms stride, 5 time steps; no GT filtering",
    }
    ready = (
        all(item["available"] for item in modules.values())
        and cuda["available"]
        and args.checkpoint.is_file()
        and all(report["repo_files"].values())
        and raw_splits["val"] and raw_splits["test"]
    )
    report["ready_for_full_evaluation"] = bool(ready)
    path = args.work_dir / "server_inspection.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print("Inspection report: {}".format(path))


if __name__ == "__main__":
    main()

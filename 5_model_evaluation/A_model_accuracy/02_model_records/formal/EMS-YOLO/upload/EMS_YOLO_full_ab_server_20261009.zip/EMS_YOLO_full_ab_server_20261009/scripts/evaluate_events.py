#!/usr/bin/env python3
"""Compute EMS-YOLO event-level metrics from box-to-event probabilities."""

from __future__ import print_function

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_ROOT))
from lib.data import validate_events  # noqa: E402
from lib.phase1_metrics import (  # noqa: E402
    event_counts, event_summary, localization_counts, localization_summary, sum_counts,
)


INDEX_PATH = PACKAGE_ROOT / "frozen" / "index.json"
THRESHOLD = 0.407
THRESHOLDS = tuple(sorted(set(
    [round(value / 100.0, 2) for value in range(5, 96, 5)] + [THRESHOLD]
)))
DENSITY_THRESHOLD_EVENTS_PER_SECOND = 20000.0
PROTOCOL = "evuav-event-metrics-v1+ems-yolo-sliding-box-to-event-v1"
ROLE_TO_SPLIT = {"validation": "val", "test": "test"}
ROLE_TO_OUTPUT = {"validation": "Validation", "test": "Test"}


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def score(loc, labels, identities, probabilities, threshold):
    return {
        "event": event_summary(event_counts(labels, probabilities, threshold)),
        "localization": localization_summary(
            localization_counts(loc, labels, identities, probabilities, threshold)
        ),
    }


def aggregate(rows):
    if not rows:
        raise ValueError("cannot aggregate an empty score set")
    events = sum_counts([
        {key: row["event"][key] for key in ("tp", "fp", "fn", "tn")} for row in rows
    ])
    localization_keys = (
        "targets", "correct_targets", "false_components", "frame_denominator",
        "scored_localization_events", "wrapped_false_pixels",
    )
    localization = sum_counts([
        {key: row["localization"][key] for key in localization_keys} for row in rows
    ])
    return {
        "event": event_summary(events),
        "localization": localization_summary(localization),
    }


def load_sequence(path):
    with np.load(str(path), allow_pickle=False) as archive:
        events = archive["ev"].copy()
        loc = archive["ev_loc"].copy()
        norm = archive["evs_norm"]
        labels = norm[:, 4].copy()
        identities = norm[:, 5].copy()
    validate_events(events, require_labels=True)
    if loc.shape != (len(events), 3) or labels.shape != (len(events),) or identities.shape != (len(events),):
        raise ValueError("EV-UAV arrays are not event-aligned: {}".format(path))
    if not np.array_equal(events["label"], labels) or not np.array_equal(events["name"], identities):
        raise ValueError("EV-UAV labels/identities disagree: {}".format(path))
    if not np.array_equal(np.column_stack((events["x"], events["y"])), loc[:, :2]):
        raise ValueError("EV-UAV coordinates disagree: {}".format(path))
    return events, loc, labels, identities


def load_probability(path, count, source_sha, checkpoint_sha):
    with np.load(str(path), allow_pickle=False) as archive:
        values = np.asarray(archive["probabilities"], dtype=np.float32)
        recorded_source = str(np.asarray(archive["source_sha256"]).item())
        recorded_checkpoint = str(np.asarray(archive["checkpoint_sha256"]).item())
        recorded_adapter = str(np.asarray(archive["adapter_protocol"]).item())
    if values.shape != (count,) or not np.all(np.isfinite(values)) or np.any((values < 0) | (values > 1)):
        raise ValueError("invalid probability file: {}".format(path))
    if recorded_source != source_sha or recorded_checkpoint != checkpoint_sha:
        raise ValueError("probability provenance mismatch: {}".format(path))
    if recorded_adapter != "ems-yolo-sliding-box-to-event-v1":
        raise ValueError("probability adapter mismatch: {}".format(path))
    return values


def exact_pr(labels, probabilities):
    order = np.argsort(-probabilities, kind="stable")
    p = probabilities[order]
    y = labels[order] == 1
    ends = np.r_[np.flatnonzero(p[1:] != p[:-1]), len(p) - 1]
    tp = np.cumsum(y, dtype=np.int64)[ends]
    precision = tp / (ends + 1)
    positives = int(y.sum())
    recall = tp / positives if positives else np.zeros(len(ends), dtype=np.float64)
    ap = float(np.sum(np.diff(np.r_[0.0, recall]) * precision)) if positives else None
    return p[ends], precision, recall, ap, positives


def write_json(path, payload):
    path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def write_rows(path, rows):
    if not rows:
        raise ValueError("empty CSV: {}".format(path))
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def threshold_key(value):
    return str(float(value))


def evaluate_role(role, args, index, records, provenance):
    split = ROLE_TO_SPLIT[role]
    names = list(index["roles"][role])
    per_sequence = []
    labels_all = []
    probabilities_all = []
    for position, name in enumerate(names, 1):
        relative = split + "/" + name
        record = records[relative]
        source = args.dataset / split / name
        source_sha = sha256(source)
        if source_sha != record["sha256"]:
            raise ValueError("dataset hash mismatch: {}".format(source))
        events, loc, labels, identities = load_sequence(source)
        probability = load_probability(
            args.predictions / role / name,
            len(events),
            source_sha,
            provenance["checkpoint_sha256"],
        )
        duration_ms = float(loc[:, 2].max() - loc[:, 2].min())
        event_rate = float(len(events) / (duration_ms / 1000.0)) if duration_ms > 0 else float("inf")
        is_high = event_rate >= DENSITY_THRESHOLD_EVENTS_PER_SECOND
        scores = {}
        for threshold in THRESHOLDS:
            scores[threshold_key(threshold)] = score(
                loc, labels, identities, probability, threshold
            )
        per_sequence.append({
            "file": name,
            "high_density": bool(is_high),
            "events": len(events),
            "duration_ms": duration_ms,
            "event_rate_hz": event_rate,
            "candidate_events": int(np.count_nonzero(probability >= THRESHOLD)),
            "probability_file_sha256": sha256(args.predictions / role / name),
            "scores": scores,
        })
        labels_all.append(labels.astype(np.uint8, copy=False))
        probabilities_all.append(probability)
        print("[event-metrics:{}] {:02d}/24 {}".format(role, position, name), flush=True)

    curve = {}
    high_curve = {}
    ordinary_curve = {}
    for threshold in THRESHOLDS:
        key = threshold_key(threshold)
        curve[key] = aggregate([row["scores"][key] for row in per_sequence])
        high_curve[key] = aggregate([
            row["scores"][key] for row in per_sequence if row["high_density"]
        ])
        ordinary_curve[key] = aggregate([
            row["scores"][key] for row in per_sequence if not row["high_density"]
        ])

    labels_joined = np.concatenate(labels_all)
    probabilities_joined = np.concatenate(probabilities_all)
    pr_thresholds, precision, recall, average_precision, target_events = exact_pr(
        labels_joined, probabilities_joined
    )
    working_key = threshold_key(THRESHOLD)
    working_per_sequence = {
        row["file"]: row["scores"][working_key] for row in per_sequence
    }
    summary = {
        "working_point": {
            "eligible": True,
            "threshold": THRESHOLD,
            "overall": curve[working_key],
            "average_precision": average_precision,
            "high_density": high_curve[working_key],
            "ordinary_density": ordinary_curve[working_key],
            "per_sequence": working_per_sequence,
        },
        "reporting_threshold": THRESHOLD,
        "reporting_threshold_kind": "frozen_legacy_validation_selected_threshold_no_new_tuning",
        "evaluation": {
            "curve": curve,
            "density_curves": {
                "high_density": high_curve,
                "ordinary_density": ordinary_curve,
            },
            "per_sequence": per_sequence,
            "average_precision": average_precision,
            "target_events": target_events,
            "sequence_count": len(per_sequence),
            "metric_protocol": PROTOCOL,
            "density_rule": "high density iff whole-sequence event rate >= 20000 events/s",
            "provenance": provenance,
        },
    }
    output = args.output / "EMS-YOLO" / ROLE_TO_OUTPUT[role] / "event_level"
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "summary.json", summary)

    per_sequence_rows = []
    for row in per_sequence:
        values = row["scores"][working_key]
        per_sequence_rows.append({
            "file": row["file"],
            "high_density": row["high_density"],
            "events": row["events"],
            "candidate_events": row["candidate_events"],
            "iou": values["event"]["iou"],
            "precision": values["event"]["precision"],
            "recall": values["event"]["recall"],
            "pd": values["localization"]["pd"],
            "fa": values["localization"]["fa"],
        })
    write_rows(output / "per_sequence.csv", per_sequence_rows)
    write_rows(output / "threshold_curve.csv", [
        {
            "threshold": key,
            "iou": value["event"]["iou"],
            "precision": value["event"]["precision"],
            "recall": value["event"]["recall"],
            "pd": value["localization"]["pd"],
            "fa": value["localization"]["fa"],
        }
        for key, value in curve.items()
    ])
    with (output / "pr_curve.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("threshold", "precision", "recall"))
        writer.writerows(zip(pr_thresholds.tolist(), precision.tolist(), recall.tolist()))
    return summary


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--provenance", type=Path, required=True)
    parser.add_argument(
        "--roles", nargs="+", choices=("validation", "test"),
        default=("validation", "test"),
    )
    return parser.parse_args()


def main():
    args = parse_args()
    args.dataset = args.dataset.resolve()
    args.predictions = args.predictions.resolve()
    args.output = args.output.resolve()
    index = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    records = {row["path"]: row for row in index["files"]}
    provenance = json.loads(args.provenance.read_text(encoding="utf-8"))
    summaries = {
        role: evaluate_role(role, args, index, records, provenance)
        for role in args.roles
    }
    write_json(args.output / "EMS-YOLO" / "event_level_summaries.json", summaries)
    print("Event-level evaluation complete: Validation + Test")


if __name__ == "__main__":
    main()


#!/usr/bin/env python3
"""Freeze EMS-YOLO code, weights and full-sequence sliding-window inputs."""

from __future__ import print_function

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
INDEX_PATH = PACKAGE_ROOT / "frozen" / "index.json"
EXPECTED_CHECKPOINT_SHA256 = "1d81e49cfc2e5973edff102011141d5ceae3ef723cedfe4f74a6b32e79849a2e"
EXPECTED_CONFIG_SHA256 = "7e3f16c972ac3c573b0a942785e1713aeaeba402f380aaa20f7389be2f8ae552"
ROLE_TO_SPLIT = {"validation": "val", "test": "test"}
WINDOW_MS = 250.0
STRIDE_MS = 100.0
TIME_STEPS = 5


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--raw-dataset", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    return parser.parse_args()


def window_starts(times):
    if len(times) == 0:
        return []
    first = float(times[0]); last = float(times[-1])
    count = int(np.floor((last - first) / STRIDE_MS)) + 1
    return [first + index * STRIDE_MS for index in range(count)]


def main():
    args = parse_args()
    repo = args.repo.resolve(); checkpoint = args.checkpoint.resolve()
    raw_root = args.raw_dataset.resolve(); work = args.work_dir.resolve()
    work.mkdir(parents=True, exist_ok=True)
    config = repo / "models" / "resnet34-cat.yaml"
    required = [
        repo / "models" / "common.py", repo / "models" / "yolo.py", config,
        repo / "utils" / "general.py", repo / "utils" / "torch_utils.py",
        repo / "get_gen1_data.py", repo / "val.py",
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise SystemExit("missing EMS-YOLO source files: {}".format(missing))
    checkpoint_sha = sha256(checkpoint)
    if checkpoint_sha != EXPECTED_CHECKPOINT_SHA256:
        raise SystemExit("checkpoint SHA-256 mismatch: {}".format(checkpoint_sha))
    config_sha = sha256(config)
    if config_sha != EXPECTED_CONFIG_SHA256:
        raise SystemExit("resnet34-cat.yaml SHA-256 mismatch: {}".format(config_sha))

    index = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    records = {item["path"]: item for item in index["files"]}
    manifest = {
        "input_protocol": "ems-yolo-full-sequence-sliding-window-v1",
        "window_ms": WINDOW_MS, "stride_ms": STRIDE_MS, "time_steps": TIME_STEPS,
        "selection_uses_ground_truth": False, "roles": {},
    }
    for role, split in ROLE_TO_SPLIT.items():
        role_rows = []
        for name in index["roles"][role]:
            path = raw_root / split / name
            record = records[split + "/" + name]
            if not path.is_file() or sha256(path) != record["sha256"]:
                raise SystemExit("raw frozen dataset mismatch: {}".format(path))
            with np.load(str(path), allow_pickle=False) as archive:
                events = archive["ev"]
                loc = archive["ev_loc"]
                norm = archive["evs_norm"]
                if len(events) != len(loc) or len(events) != len(norm) or len(events) != int(record["events"]):
                    raise SystemExit("unaligned or wrong event count: {}".format(path))
                starts = window_starts(events["t"])
            if not starts:
                raise SystemExit("empty sequence: {}".format(path))
            role_rows.append({
                "sequence": name, "source_sha256": record["sha256"],
                "events": int(record["events"]), "window_count": len(starts),
                "window_starts_ms": starts,
            })
        manifest["roles"][role] = {
            "sequence_count": len(role_rows),
            "window_count": sum(row["window_count"] for row in role_rows),
            "sequences": role_rows,
        }

    provenance = {
        "evaluation_id": "EMS-YOLO", "model": "EMS-YOLO",
        "numeric_path": "modified_ems_yolo_float32_snn_cuda",
        "checkpoint": str(checkpoint), "checkpoint_sha256": checkpoint_sha,
        "config": str(config), "config_sha256": config_sha,
        "raw_dataset": str(raw_root), "frozen_index_sha256": sha256(INDEX_PATH),
        "source_files": [{"path": str(path), "sha256": sha256(path)} for path in required],
        "input_window_ms": WINDOW_MS, "input_stride_ms": STRIDE_MS,
        "time_steps": TIME_STEPS, "frozen_confidence_threshold": 0.407,
        "threshold_origin": "historical validation F1 peak reported before formal admission; no new Validation/Test tuning",
        "box_to_event_protocol": "ems-yolo-sliding-box-to-event-v1",
        "window_selection": "all stride-aligned raw-sequence windows; no label/name/GT filtering; tail windows are zero-padded implicitly",
    }
    (work / "sample_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (work / "provenance.json").write_text(json.dumps(provenance, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("Preflight passed: 24 Validation + 24 Test sequences; full sequence scan uses no GT window selection")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Evaluate EMS-YOLO with the frozen observable-event-track HOTA protocol."""

from __future__ import print_function

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_ROOT))

from lib.data import load_events  # noqa: E402
from lib.target_tracking_metrics import (  # noqa: E402
    HOTA_ALPHAS,
    PROTOCOL_ID,
    WINDOW_MS,
    combine_hota_raw,
    evaluate_sequence,
    hota_metrics,
    percentile95,
)


INDEX_PATH = PACKAGE_ROOT / "frozen" / "index.json"
PROTOCOL_PATH = PACKAGE_ROOT / "frozen" / "target_track_protocol.json"
THRESHOLD = 0.407
ROLE_TO_SPLIT = {"validation": "val", "test": "test"}
ROLE_TO_OUTPUT = {"validation": "Validation", "test": "Test"}
DETECTION_FIELDS = (
    "data_role", "model", "sequence", "window_index", "window_start_ms",
    "entity_type", "track_id", "x1", "y1", "x2_exclusive", "y2_exclusive",
    "confidence", "matched_track_id_iou_0_5", "match_iou", "match_status",
)


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def jsonable(value):
    if isinstance(value, np.ndarray):
        return [jsonable(item) for item in value.tolist()]
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    return value


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(jsonable(payload), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def write_csv(path, rows):
    if not rows:
        raise ValueError("refusing to write empty CSV: {}".format(path))
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def load_probability(path, expected_count, expected_source_sha, expected_checkpoint_sha):
    with np.load(str(path), allow_pickle=False) as archive:
        probability = np.asarray(archive["probabilities"], dtype=np.float32)
        source_sha = str(np.asarray(archive["source_sha256"]).item())
        checkpoint_sha = str(np.asarray(archive["checkpoint_sha256"]).item())
        adapter_protocol = str(np.asarray(archive["adapter_protocol"]).item())
    if probability.shape != (expected_count,):
        raise ValueError("invalid probability shape: {}".format(path))
    if not np.all(np.isfinite(probability)) or not np.all((probability >= 0.0) & (probability <= 1.0)):
        raise ValueError("invalid probability values: {}".format(path))
    if source_sha != expected_source_sha:
        raise ValueError("probability/source mismatch: {}".format(path))
    if checkpoint_sha != expected_checkpoint_sha:
        raise ValueError("probability/checkpoint mismatch: {}".format(path))
    if adapter_protocol != "ems-yolo-sliding-box-to-event-v1":
        raise ValueError("probability/adapter mismatch: {}".format(path))
    return probability


def counts_by_alpha(raw):
    return {
        "{:.2f}".format(float(alpha)): {
            "tp": int(raw["tp"][position]),
            "fn": int(raw["fn"][position]),
            "fp": int(raw["fp"][position]),
        }
        for position, alpha in enumerate(raw["alphas"])
    }


def detection_rows(sequence, role, result):
    matches = result["matches_iou_0_5"]
    for entity_type, detections in (("gt", result["ground_truth"]), ("pred", result["predictions"])):
        for item in detections:
            match = matches.get((item.frame, entity_type, item.identity))
            x1, y1, x2, y2 = item.bbox
            yield {
                "data_role": role,
                "model": "EMS-YOLO",
                "sequence": sequence,
                "window_index": item.frame,
                "window_start_ms": item.frame * WINDOW_MS,
                "entity_type": entity_type,
                "track_id": item.identity,
                "x1": x1,
                "y1": y1,
                "x2_exclusive": x2,
                "y2_exclusive": y2,
                "confidence": item.confidence if entity_type == "pred" else "",
                "matched_track_id_iou_0_5": "" if match is None else match[0],
                "match_iou": "" if match is None else match[1],
                "match_status": "matched" if match is not None else "unmatched",
            }


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--provenance", type=Path, required=True)
    parser.add_argument("--roles", nargs="+", choices=("validation", "test"), default=("validation", "test"))
    return parser.parse_args()


def evaluate_role(role, args, index, records, protocol, provenance):
    split = ROLE_TO_SPLIT[role]
    names = list(index["roles"][role])
    selected = protocol["selected"]
    adapter_args = {
        "cluster_radius": int(selected["cluster_radius_px"]),
        "association_distance": float(selected["association_distance_px_per_50ms"]),
        "max_missed_windows": int(selected["max_missed_windows"]),
    }
    output = args.output / "EMS-YOLO" / ROLE_TO_OUTPUT[role] / "target_track_level"
    output.mkdir(parents=True, exist_ok=True)
    detection_path = output / "detections.csv"
    raw_items = []
    sequence_rows = []
    all_misses = []
    total_events = 0
    with detection_path.open("w", encoding="utf-8-sig", newline="") as stream:
        detection_writer = csv.DictWriter(stream, fieldnames=DETECTION_FIELDS)
        detection_writer.writeheader()
        for position, name in enumerate(names, 1):
            relative = split + "/" + name
            record = records[relative]
            source_path = args.dataset / split / name
            source_sha = sha256(source_path)
            if source_sha != record["sha256"]:
                raise ValueError("dataset hash mismatch during evaluation: {}".format(source_path))
            events = load_events(source_path, require_labels=True)
            expected_count = int(record["events"])
            if len(events) != expected_count:
                raise ValueError("event count mismatch: {}".format(source_path))
            probability = load_probability(
                args.predictions / role / name,
                expected_count,
                source_sha,
                provenance["checkpoint_sha256"],
            )
            result = evaluate_sequence(events, probability, THRESHOLD, **adapter_args)
            raw_items.append(result["raw"])
            all_misses.extend(result["longest_miss_per_track_ms"])
            averaged = result["metrics"]["averaged"]
            counts = result["metrics"]["counts"]
            sequence_rows.append({
                "data_role": role,
                "model": "EMS-YOLO",
                "sequence": name,
                "events": expected_count,
                "HOTA": averaged["HOTA"],
                "DetA": averaged["DetA"],
                "DetRe": averaged["DetRe"],
                "DetPr": averaged["DetPr"],
                "AssA": averaged["AssA"],
                "AssRe": averaged["AssRe"],
                "AssPr": averaged["AssPr"],
                "LocA": averaged["LocA"],
                "longest_miss_p95_ms": percentile95(result["longest_miss_per_track_ms"]),
                "gt_detections": counts["gt_detections"],
                "pred_detections": counts["pred_detections"],
                "gt_tracks": counts["gt_tracks"],
                "pred_tracks": counts["pred_tracks"],
            })
            detection_writer.writerows(detection_rows(name, role, result))
            total_events += expected_count
            print("[evaluate:{}] {:02d}/24 {}".format(role, position, name), flush=True)

    raw = combine_hota_raw(raw_items)
    metrics = hota_metrics(raw)
    prediction_manifest_path = args.predictions / "manifest.json"
    summary = {
        "status": "complete",
        "metric_protocol": PROTOCOL_ID,
        "data_role": role,
        "model": "EMS-YOLO",
        "numeric_path": provenance["numeric_path"],
        "threshold": THRESHOLD,
        "window_ms": WINDOW_MS,
        "hota_alphas": HOTA_ALPHAS,
        "adapter": selected,
        "metrics": metrics,
        "counts_by_alpha": counts_by_alpha(raw),
        "longest_continuous_miss_p95_ms": percentile95(all_misses),
        "sequence_count": len(names),
        "events": total_events,
        "data_index_sha256": sha256(INDEX_PATH),
        "frozen_protocol_sha256": sha256(PROTOCOL_PATH),
        "prediction_manifest_sha256": sha256(prediction_manifest_path),
        "provenance": provenance,
        "limitations": [
            "GT boxes are observable target-event support boxes, not manually annotated physical UAV boxes.",
            "A target-silent 50 ms window creates no GT detection and is not counted as a miss.",
            "The score evaluates the model plus the shared frozen clustering and association adapter.",
        ],
    }
    write_json(output / "summary.json", summary)
    write_csv(output / "per_sequence.csv", sequence_rows)
    return summary


def main():
    args = parse_args()
    args.dataset = args.dataset.resolve()
    args.predictions = args.predictions.resolve()
    args.output = args.output.resolve()
    index = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    records = {item["path"]: item for item in index["files"]}
    protocol = json.loads(PROTOCOL_PATH.read_text(encoding="utf-8"))
    provenance = json.loads(args.provenance.read_text(encoding="utf-8"))
    if protocol.get("protocol") != PROTOCOL_ID:
        raise SystemExit("Frozen protocol ID mismatch")
    selected = protocol.get("selected", {})
    frozen_tuple = (
        int(selected.get("cluster_radius_px", -1)),
        float(selected.get("association_distance_px_per_50ms", -1)),
        int(selected.get("max_missed_windows", -1)),
    )
    if frozen_tuple != (3, 20.0, 20):
        raise SystemExit("Frozen adapter values were modified")
    if sha256(INDEX_PATH) != protocol.get("data_index_sha256"):
        raise SystemExit("Frozen data index/protocol mismatch")
    summaries = {}
    for role in args.roles:
        summaries[role] = evaluate_role(role, args, index, records, protocol, provenance)
    write_json(args.output / "EMS-YOLO" / "target_track_summaries.json", summaries)
    print(json.dumps(jsonable(summaries), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()


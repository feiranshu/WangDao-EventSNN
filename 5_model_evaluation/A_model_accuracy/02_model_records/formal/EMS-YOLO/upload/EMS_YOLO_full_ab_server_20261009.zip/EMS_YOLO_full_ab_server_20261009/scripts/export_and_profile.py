#!/usr/bin/env python3
"""Run full-sequence EMS-YOLO inference, export event probabilities, and profile B01-B04."""

from __future__ import print_function

import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys

import numpy as np


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
INDEX_PATH = PACKAGE_ROOT / "frozen" / "index.json"
ROLE_TO_SPLIT = {"validation": "val", "test": "test"}
ROLE_TO_OUTPUT = {"validation": "Validation", "test": "Test"}
PROTOCOL = "ems-yolo-fp32-snn-effective-ops-v1"
ADAPTER_PROTOCOL = "ems-yolo-sliding-box-to-event-v1"
MODEL_HEIGHT, MODEL_WIDTH = 256, 320
PREPROCESS_HEIGHT, PREPROCESS_WIDTH = 240, 304
WINDOW_MS, TIME_STEPS = 250.0, 5


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--raw-dataset", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--device", default="0")
    parser.add_argument("--roles", nargs="+", choices=("validation", "test"), default=("validation", "test"))
    return parser.parse_args()


def load_raw(path):
    with np.load(str(path), allow_pickle=False) as archive:
        events = archive["ev"].copy()
        loc = np.asarray(archive["ev_loc"]).copy()
        norm = np.asarray(archive["evs_norm"]).copy()
    if len(events) != len(loc) or len(events) != len(norm):
        raise ValueError("unaligned raw event arrays: {}".format(path))
    return events, loc, norm


def render_window(events, norm, start_ms):
    """Reproduce the admitted EMS-YOLO 5x240x304x3 event-frame representation without labels."""
    image = np.full((TIME_STEPS, PREPROCESS_HEIGHT, PREPROCESS_WIDTH, 3), 127, dtype=np.uint8)
    bin_ms = WINDOW_MS / TIME_STEPS
    for step in range(TIME_STEPS):
        lower = start_ms + step * bin_ms; upper = lower + bin_ms
        mask = (events["t"] >= lower) & (events["t"] < upper)
        values = norm[mask]
        if len(values) == 0:
            continue
        x = np.clip((values[:, 0] * PREPROCESS_WIDTH).astype(np.int64), 0, PREPROCESS_WIDTH - 1)
        y = np.clip((values[:, 1] * PREPROCESS_HEIGHT).astype(np.int64), 0, PREPROCESS_HEIGHT - 1)
        image[step, y, x, :] = (255 * values[:, 3]).astype(np.uint8)[:, None]
    return image


def make_input(image, torch, functional, device):
    array = np.transpose(np.asarray(image, dtype=np.float32), (0, 3, 1, 2))
    tensor = torch.from_numpy(np.ascontiguousarray(array)).unsqueeze(0).to(device, non_blocking=True).float() / 255.0
    tensor = functional.interpolate(
        tensor.view(TIME_STEPS, 3, PREPROCESS_HEIGHT, PREPROCESS_WIDTH),
        size=(MODEL_HEIGHT, MODEL_WIDTH), mode="bilinear", align_corners=False,
    ).view(1, TIME_STEPS, 3, MODEL_HEIGHT, MODEL_WIDTH)
    return tensor


def boxes_to_event_probabilities(events, norm, window_predictions):
    """Take the maximum confidence from every sliding detector window covering each event."""
    probability = np.zeros(len(events), dtype=np.float32)
    if len(events) == 0:
        return probability
    times = np.asarray(events["t"], dtype=np.float64)
    x_pre = np.clip((norm[:, 0] * PREPROCESS_WIDTH).astype(np.int64), 0, PREPROCESS_WIDTH - 1)
    y_pre = np.clip((norm[:, 1] * PREPROCESS_HEIGHT).astype(np.int64), 0, PREPROCESS_HEIGHT - 1)
    x_model = (x_pre + 0.5) * (MODEL_WIDTH / PREPROCESS_WIDTH) - 0.5
    y_model = (y_pre + 0.5) * (MODEL_HEIGHT / PREPROCESS_HEIGHT) - 0.5
    for window in window_predictions:
        start = float(window["start_ms"])
        event_index = np.flatnonzero((times >= start) & (times < start + WINDOW_MS))
        if not len(event_index):
            continue
        for box in window["boxes"]:
            x1, y1, x2, y2, confidence = [float(item) for item in box[:5]]
            inside = (
                (x_model[event_index] >= x1) & (x_model[event_index] < x2)
                & (y_model[event_index] >= y1) & (y_model[event_index] < y2)
            )
            if np.any(inside):
                selected = event_index[inside]
                probability[selected] = np.maximum(probability[selected], np.float32(confidence))
    return probability


class OperationProfiler(object):
    def __init__(self, torch, model):
        self.torch = torch; self.handles = []; self.rows = []
        for name, module in model.named_modules():
            if isinstance(module, torch.nn.Conv2d):
                self.handles.append(module.register_forward_hook(self._conv_hook(name)))
            elif isinstance(module, torch.nn.Linear):
                self.handles.append(module.register_forward_hook(self._linear_hook(name)))

    def reset(self): self.rows = []
    def close(self):
        for handle in self.handles: handle.remove()

    def _conv_hook(self, name):
        def hook(module, inputs, output):
            torch = self.torch; source = inputs[0].detach()
            if source.ndim == 5:
                flat = source.reshape(-1, source.shape[-3], source.shape[-2], source.shape[-1])
            elif source.ndim == 4:
                flat = source
            else:
                raise RuntimeError("unsupported conv input rank {} at {}".format(source.ndim, name))
            kernel = int(module.kernel_size[0] * module.kernel_size[1])
            dense = int(output.numel()) * int(module.in_channels // module.groups) * kernel
            binary = bool(torch.all((flat == 0) | (flat == 1)).item())
            with torch.no_grad():
                effective = int(round(float(torch.nn.functional.conv2d(
                    (flat != 0).to(dtype=torch.float32),
                    (module.weight.detach() != 0).to(dtype=torch.float32),
                    None, module.stride, module.padding, module.dilation, module.groups,
                ).sum().item())))
            self.rows.append({
                "module": name, "operator": "conv2d", "dense_macs": dense,
                "effective_macs": 0 if binary else effective,
                "effective_acs": effective if binary else 0,
                "binary_spike_input": binary,
            })
        return hook

    def _linear_hook(self, name):
        def hook(module, inputs, output):
            source = inputs[0].detach(); vectors = int(source.numel() // module.in_features)
            dense = vectors * int(module.in_features) * int(module.out_features)
            binary = bool(self.torch.all((source == 0) | (source == 1)).item())
            nonzero_weight_per_input = (module.weight.detach() != 0).sum(dim=0)
            expanded = source.reshape(-1, module.in_features) != 0
            effective = int((expanded.to(nonzero_weight_per_input.dtype) * nonzero_weight_per_input).sum().item())
            self.rows.append({
                "module": name, "operator": "linear", "dense_macs": dense,
                "effective_macs": 0 if binary else effective,
                "effective_acs": effective if binary else 0,
                "binary_spike_input": binary,
            })
        return hook

    def result(self):
        if not self.rows:
            raise RuntimeError("operation profiler recorded no Conv2d/Linear operators")
        return {
            "dense_macs": int(sum(row["dense_macs"] for row in self.rows)),
            "effective_macs": int(sum(row["effective_macs"] for row in self.rows)),
            "effective_acs": int(sum(row["effective_acs"] for row in self.rows)),
            "operator_count": len(self.rows),
        }


def model_profile(model):
    parameters = [parameter for parameter in model.parameters() if parameter.requires_grad]
    state = model.state_dict()
    return {
        "total_weight_parameters": int(sum(parameter.numel() for parameter in parameters)),
        "total_tensor_payload_bytes": int(sum(tensor.numel() * tensor.element_size() for tensor in state.values())),
        "trainable_tensor_count": len(parameters), "state_tensor_count": len(state),
        "parameter_dtype_bytes": sorted(set(int(parameter.element_size()) for parameter in parameters)),
    }


def summarize(static, rows):
    if not rows: raise ValueError("empty per-sequence complexity rows")
    count = len(rows); dense = sum(row["dense_macs"] for row in rows)
    mac = sum(row["effective_macs"] for row in rows); ac = sum(row["effective_acs"] for row in rows)
    result = dict(static)
    result.update({
        "sequences": count, "events": int(sum(row["events"] for row in rows)),
        "inference_windows": int(sum(row["samples"] for row in rows)),
        "total_dense_macs": int(dense), "total_effective_macs": int(mac), "effective_acs": int(ac),
        "dense_macs_per_sequence": float(dense) / count,
        "effective_macs_per_sequence": float(mac) / count,
        "effective_acs_per_sequence": float(ac) / count,
        "effective_ops_per_sequence": float(mac + ac) / count,
        "dense_definition": "all Conv2d/Linear structural connections over every 250 ms/100 ms stride full-sequence window and five time steps",
        "effective_definition": "nonzero input x nonzero weight connections; binary spike input is AC, analog input is MAC",
    })
    return result


def main():
    args = parse_args(); repo = args.repo.resolve(); checkpoint = args.checkpoint.resolve()
    work = args.work_dir.resolve(); raw_root = args.raw_dataset.resolve()
    provenance = json.loads((work / "provenance.json").read_text(encoding="utf-8"))
    manifest = json.loads((work / "sample_manifest.json").read_text(encoding="utf-8"))
    index = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    if sha256(checkpoint) != provenance["checkpoint_sha256"]: raise SystemExit("checkpoint changed after preflight")
    os.chdir(str(repo)); sys.path.insert(0, str(repo))
    import torch
    select_device = importlib.import_module("utils.torch_utils").select_device
    common = importlib.import_module("models.common")
    non_max_suppression = importlib.import_module("utils.general").non_max_suppression
    device = select_device(args.device, batch_size=1)
    if device.type != "cuda": raise SystemExit("EMS-YOLO formal evaluation requires CUDA")
    backend = common.DetectMultiBackend(str(checkpoint), device=device, dnn=False)
    backend.model.float().eval(); model = backend.model
    with torch.no_grad(): backend(torch.zeros(1, 5, 3, MODEL_HEIGHT, MODEL_WIDTH, device=device), val=True)
    static = model_profile(model); profiler = OperationProfiler(torch, model); prediction_files = []
    try:
        for role in args.roles:
            split = ROLE_TO_SPLIT[role]; names = list(index["roles"][role])
            manifest_rows = {row["sequence"]: row for row in manifest["roles"][role]["sequences"]}
            sequence_complexity = []
            for sequence_position, name in enumerate(names, 1):
                raw_path = raw_root / split / name; events, loc, norm = load_raw(raw_path)
                windows = []; totals = {"dense_macs": 0, "effective_macs": 0, "effective_acs": 0}; operator_count = 0
                for window_index, start_ms in enumerate(manifest_rows[name]["window_starts_ms"]):
                    tensor = make_input(render_window(events, norm, float(start_ms)), torch, torch.nn.functional, device)
                    profiler.reset()
                    with torch.no_grad():
                        raw, _ = backend(tensor, val=True)
                        detections = non_max_suppression(raw, 0.001, 0.45, multi_label=True, agnostic=False)[0]
                    counts = profiler.result(); operator_count += counts["operator_count"]
                    for key in totals: totals[key] += counts[key]
                    boxes = detections[:, :6].detach().cpu().numpy().astype(np.float32).tolist() if len(detections) else []
                    windows.append({"window_index": window_index, "start_ms": float(start_ms), "boxes": boxes})
                    del tensor, raw, detections
                probability = boxes_to_event_probabilities(events, norm, windows)
                output = work / "predictions" / role / name; output.parent.mkdir(parents=True, exist_ok=True)
                np.savez_compressed(str(output), probabilities=probability, source_sha256=np.asarray(sha256(raw_path)),
                                    checkpoint_sha256=np.asarray(provenance["checkpoint_sha256"]), adapter_protocol=np.asarray(ADAPTER_PROTOCOL))
                detection_output = work / "detections" / role / (Path(name).stem + ".json")
                detection_output.parent.mkdir(parents=True, exist_ok=True)
                detection_output.write_text(json.dumps({
                    "sequence": name, "window_ms": WINDOW_MS, "stride_ms": 100.0,
                    "selection_uses_ground_truth": False, "coordinate_space": [MODEL_WIDTH, MODEL_HEIGHT],
                    "windows": windows,
                }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                samples = len(windows)
                sequence_complexity.append({
                    "sequence": name, "events": len(events), "samples": samples,
                    "dense_macs": totals["dense_macs"], "effective_macs": totals["effective_macs"],
                    "effective_acs": totals["effective_acs"],
                    "effective_ops_mac_plus_ac": totals["effective_macs"] + totals["effective_acs"],
                    "operator_count": operator_count,
                })
                prediction_files.append({"role": role, "sequence": name, "path": str(output.relative_to(work)),
                                         "events": len(events), "inference_windows": samples, "prediction_sha256": sha256(output)})
                print("[ems-yolo:{}] {:02d}/24 {} windows={}".format(role, sequence_position, name, samples), flush=True)
            summary = summarize(static, sequence_complexity)
            destination = work / "results" / "EMS-YOLO" / "complexity" / ROLE_TO_OUTPUT[role] / "summary.json"
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(json.dumps({
                "evaluation_id": "EMS-YOLO", "model": "EMS-YOLO", "data_split": role,
                "protocol": PROTOCOL, "numeric_path": provenance["numeric_path"],
                "source_weights_sha256": provenance["checkpoint_sha256"], "summary": summary,
                "per_sequence": sequence_complexity,
            }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    finally:
        profiler.close()
    common_output = work / "results" / "EMS-YOLO" / "complexity" / "common" / "model_profile.json"
    common_output.parent.mkdir(parents=True, exist_ok=True)
    common_output.write_text(json.dumps({
        "evaluation_id": "EMS-YOLO", "model": "EMS-YOLO", "protocol": PROTOCOL,
        "numeric_path": provenance["numeric_path"], "source_weights_sha256": provenance["checkpoint_sha256"],
        "summary": static,
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (work / "predictions" / "manifest.json").write_text(json.dumps({
        "model": "EMS-YOLO", "adapter_protocol": ADAPTER_PROTOCOL,
        "checkpoint_sha256": provenance["checkpoint_sha256"], "files": prediction_files,
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("EMS-YOLO predictions and B complexity complete")


if __name__ == "__main__":
    main()

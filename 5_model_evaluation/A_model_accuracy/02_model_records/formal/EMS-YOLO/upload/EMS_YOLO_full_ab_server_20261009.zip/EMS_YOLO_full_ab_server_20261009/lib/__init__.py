"""Frozen EV-UAV target-track evaluation library."""


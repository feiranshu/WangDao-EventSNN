# EMS-YOLO 在 EV-UAV 上的 A+B 正式补测包

本包用于服务器上已经跑通的改进版 EMS-YOLO 工程。它不会修改工程、权重或数据，只读取现有文件，在独立工作区导出逐事件概率并完成 A、B 两类正式指标。

## 为什么现有报告还不能直接入表

实验报告中的 `mAP@0.5=0.446` 是 250 ms 检测样本上的目标框指标，不等于本项目 A01 Event AP，也不能推算 A14-A22 轨迹指标。正式比较需要把检测框转换成与原始事件一一对应的概率，然后复用与 H2、H2-plus 相同的事件级和目标轨迹级评测代码。

## 冻结的模型与接口

- `evaluation_id`：`EMS-YOLO`。
- 数值路径：改进版 EMS-YOLO，FP32 SNN，CUDA。
- 权重：`runs/train/exp3/weights/best.pt`，SHA-256 必须为 `1d81e49cfc2e5973edff102011141d5ceae3ef723cedfe4f74a6b32e79849a2e`。
- 配置：`models/resnet34-cat.yaml`，SHA-256 必须为 `7e3f16c972ac3c573b0a942785e1713aeaeba402f380aaa20f7389be2f8ae552`。
- 输入：直接从每条原始序列生成 250 ms 窗、100 ms 步长、5 个时间步的完整滑窗；不读取预处理 `val.txt/test.txt`，不使用 GT 筛选窗口。
- 固定置信度阈值：0.407。该阈值来自入选前报告中的 Validation F1 峰值，不在本次 Validation/Test 上重新调参。因此 Test 是主要无偏横向结果，Validation 必须保留“历史阈值选择相关”说明。

## 检测框到逐事件概率

模型对每个 250 ms 滑窗输出目标框。图像张量严格复现原训练预处理：由归一化事件坐标先生成 304×240 三通道事件帧，再双线性缩放到 320×256。原预处理只保存含目标标签的窗口，这会泄漏 GT 并漏掉背景 FP，因此正式评测改为全序列无标签滑窗：

1. 以 100 ms 步长扫描所有窗口，包括纯背景和低事件量窗口，序列尾部在事件之外自然保持中性像素；
2. 对每个原始事件，检查所有覆盖它的滑窗预测框；
3. 若事件中心落入一个或多个框，取全部覆盖框的最大置信度；
4. 若未落入任何框，概率为 0；
5. 不读取事件的 `label` 或 `name` 来生成输入选择或预测。

这样可生成与原始事件严格一一对应的概率，随后计算 A01-A13 和 A14-A22。该适配器评价的是“EMS-YOLO + 固定框到事件适配器”，报告中会保留这个边界。

## B 类复杂度口径

- B01：加载冻结权重后的可训练参数量。
- B02：加载后 `state_dict` 张量 payload 字节数，不是压缩 checkpoint 文件大小。
- B03：5 个时间步中全部 Conv2d/Linear 结构连接的稠密 MAC。
- B04a：非零模拟输入与非零权重连接的有效 MAC。
- B04b：二值脉冲输入与非零权重连接的有效 AC。
- B04c：`B04a + B04b`，这是与 B03 稠密 MAC 正式比较的量。

统计覆盖模型前向中的 Conv2d/Linear，不包含 NMS、框到事件适配器或数据加载。运行时是否为二值脉冲由实际层输入逐次判定，不把整网武断地全部记为 AC。

## 第一步：检查环境

假设工程位于 `/export01/frshu/experiment/EMS-YOLO`。先找到原始 EV-UAV 数据目录；它必须包含冻结的 `val/`、`test/` NPZ 文件。包会直接从原始 NPZ 生成输入，不要求服务器已有 `val.txt/test.txt` 或预处理 `.npy`。

```bash
cd /export01/frshu/experiment
unzip EMS_YOLO_full_ab_server_20261009.zip
cd EMS_YOLO_full_ab_server_20261009
conda activate <你已跑通EMS-YOLO的环境>
bash inspect_server.sh \
  --raw-dataset /absolute/path/to/EV-UAV-dataset
```

检查器只写 `server_inspection.json`，不会安装或改变环境。确认其中 `ready_for_full_evaluation` 为 `true`。

## 第二步：一次完成 A+B

```bash
bash run_all.sh \
  --raw-dataset /absolute/path/to/EV-UAV-dataset
```

完整形式：

```bash
bash run_all.sh \
  --repo /export01/frshu/experiment/EMS-YOLO \
  --checkpoint /export01/frshu/experiment/EMS-YOLO/runs/train/exp3/weights/best.pt \
  --raw-dataset /absolute/path/to/EV-UAV-dataset \
  --work-dir /export01/frshu/experiment/ems_yolo_evaluation_workspace \
  --device 0
```

预检会严格核对权重、配置、48 条原始序列哈希、事件数以及 Validation/Test 各 24 条序列。窗口起点仅由原始事件时间和固定 100 ms 步长确定，并写入 `sample_manifest.json`；不接受外部样本列表，也不会因窗口是否含目标而跳过。

## 输出

```text
results/EMS-YOLO/
├── Validation/
│   ├── event_level/{summary.json,per_sequence.csv,threshold_curve.csv,pr_curve.csv}
│   └── target_track_level/{summary.json,per_sequence.csv,detections.csv}
├── Test/
│   ├── event_level/{summary.json,per_sequence.csv,threshold_curve.csv,pr_curve.csv}
│   └── target_track_level/{summary.json,per_sequence.csv,detections.csv}
└── complexity/
    ├── common/model_profile.json
    ├── Validation/summary.json
    └── Test/summary.json
```

成功后下载工作区中的：

- `EMS_YOLO_full_ab_return_*.zip`
- 同名 `.sha256`

本地导入：

```bash
python 1_H2_model_improvement/implementation/software/scripts/import_ems_yolo_results.py \
  /path/to/EMS_YOLO_full_ab_return_YYYYMMDD_HHMMSS.zip
```

导入器会验证回传清单和所有 SHA-256，将 Validation/Test 分别写入 A、B 正式记录，然后重建全部分指标 CSV 和完整性表。

## 失败时不要绕过的检查

- 权重或配置哈希不同：说明不是本次批准入选的冻结模型。
- 原始数据哈希不同：无法与 H2/H2-plus 公平比较。
- Validation/Test 不是各 24 条或冻结原始序列哈希不一致：先修正原始数据目录，禁止绕过预检。
- CUDA 不可用或模型无法加载：先在同一环境复现原来的 `val.py`，再重跑本包。
- 显存不足：不要改变输入尺寸或时间步；可清空其他 GPU 任务后重跑。
